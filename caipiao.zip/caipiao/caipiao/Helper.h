//
//  Helper.h
//  酷食科技
//
//  Created by dahaoge on 16/1/27.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Helper : NSObject

/**********************          群聊              **************************/
/**
 *处理透传消息
 *
 */
-(NSString *)returnGroupMessage:(NSDictionary *)dics andAction:(NSString *)action;
+(CGFloat)returnheithtFloatAndNotAdapter:(NSString *)ss andWith:(NSInteger)with;
+(CGFloat)returnheithtFloatAndNotAdapter:(NSString *)ss andWith:(NSInteger)with andFont:(NSInteger)Font;
+(CGFloat)returnWithFloatAndNotAdapter:(NSString *)ss andWith:(NSInteger)with andFont:(NSInteger)Font;
+(NSString *)setImgWithIV:(UIImageView *)iv imageCount:(NSInteger)count andImageArr:(NSArray *)imageArrayAll;
#pragma mark -判断输入是否错误提示方法
/**
 *
 *判断输入是否错误提示方法
 *
 */
- (void)alertViewWith:(NSString *)title
              content:(NSString *)message
;
/**********************          群聊              **************************/
/**********************          行业圈              **************************/
+ (NSString *) returnUploadContent:(NSString *)content;
+ (NSString *) returnUploadTitle:(NSString *)content;


+ (NSString *)distanceTimeWithBeforeTime:(double)beTime;
+(NSString *)allTimeIntervalWith:(double)beTime;

//根据文子获取高度

+(CGFloat)returnheithtContent:(NSString *)content andWith:(NSInteger)with andSize:(NSInteger)size;

+(CGFloat)returnFloat:(NSString *)ss;
+(CGFloat)returnheithtFloat:(NSString *)ss andWith:(NSInteger)with andSize:(NSInteger)size;
//根据文子获取宽度
+(CGFloat)returnWithFloat:(NSString *)ss;

/**********************          行业圈      **************************/
#pragma mark -判断手机号-----企业电话-------身份证号
/**
 *判断手机号
 */
+ (BOOL)judgePhoneNumber:(NSString *)phoneNumber;
+(BOOL)JudgeEnterprisePhoneNumber:(NSString *)EnterPriseNumber;

+(BOOL)CheckingID:(NSString *)IDNumber;

#pragma mark------拿到输入 选择cell的左边距
+(CGFloat)GetCellLeftInterVal;

#pragma mark------判断用户身份
+(NSString *)judgeStatusWIth:(int)Sign  Kind:(int)Kind;//kind=1 店铺首页 kind=0 其他地方

#pragma mark------判断相机--图片能否使用
+(BOOL)CheckIfCanTakePhotoCV:(UIViewController *)Controller;
+(BOOL)CheckifImageCanReadCV:(UIViewController *)Controller;
+(BOOL)CheckIfCanTakeLocationCV:(UIViewController *)Controller;


#pragma mark------得到图片url
+(NSURL *)GetImageUrlWithStr:(NSString *)ImageStr;

#pragma mark--------转化请求的时间数据(资讯样式)
+(NSString *)TransformTimeDate:(id)DateStr;
//年月日样式
+(NSString *)TransformTimeDateTOYead:(id)DateStr;

#pragma mark--------时间长短格式判断(供需、资讯)--
+(NSString *)TimeIntervalWith:(NSString *)TimeStr;

#pragma mark--------由色值得到图片-----

+(UIImage *)createImageWithColor:(UIColor *)color;

#pragma mark-得到省份uid  城市uid  省份列表 城市列表
+(NSString *)GetProvinceUidWithStr:(NSString *)Province;
+(NSString *)GetCityUidWithStr:(NSString *)City;
+(NSArray *)GetProvinceArr;
+(NSDictionary *)GetCityDic;

#pragma mark -shareSDK自定义分享菜单
/**
 *shareSDK自定义分享菜单
 */
+(void)shareWithContent:(id)publishContent;//自定义分享界面

#pragma mark -AFHTTPSessionManager获取manager
+ (AFHTTPSessionManager *)helperForManager;
@end

@interface UIView (zishiying)


#pragma mark -自适应宽度
/**
 *
 *自适应宽度
 *
 */
- (CGRect)getWidth:(NSString *)text
         WithHight:(CGFloat)hight
         WithFrame:(CGRect)originalFrame;


#pragma mark -自适应高度
/**
 *
 *自适应高度
 *
 */
- (CGRect)getHight:(NSString *)text
         WithWidth:(CGFloat)width
         WithFrame:(CGRect)originalFrame;

#pragma mark -------------------------------------------------------------------添加间距
-(NSMutableAttributedString *)addSpacingWithContent:(NSString *)content;

@end

@interface UIView (shuaxin)

typedef void (^AlertBlock)(NSString *text);
#pragma mark -自定义下拉刷新gif图片
/**
 *
 *自定义下拉刷新gif图片
 */
@end


@interface UIViewController (alert)
typedef void (^UIActionSheetBlock)(NSInteger title);


#pragma mark -判断输入是否错误提示方法
/**
 *
 *判断输入是否错误提示方法
 *
 */
- (void)alertActionWith:(NSString *)title
                content:(NSString *)message
             alertStyle:(UIAlertControllerStyle)style
            cancelBlock:(UIActionSheetBlock)cancelBlock
                 isSure:(BOOL)sure;
- (void)alertActionWith:(NSString *)title
                content:(NSString *)message
             alertStyle:(UIAlertControllerStyle)style
                 isSure:(BOOL)sure;






#pragma mark -找出导航栏的底部横线
/**
 *
 *找出导航栏的底部横线
 *
 */
- (UIImageView *)findHairlineImageViewUnder:(UIView *)view;

#pragma mark -观察键盘事件
/**
 *
 *观察键盘事件
 *
 */

- (void)addObserveForKeyboardWithObserve:(UIViewController *)observe;

#pragma mark -无网提示

-(void)requestNoNetworkTips:(UIView *)view andContent:(NSString *)content;
#pragma mark 加载
/**
 *
 *加载
 *
 */
-(void)startRequests:(UIView *)view andContent:(NSString *)content;
-(void)startRequests:(UIView *)view;
-(void)endRequests:(UIView *)view;

-(void)startRequests:(UIView *)view Message:(NSString *)ShowMessage;

#pragma mark ------------------------------------------------------------------判断输入框最大输入长度
-(BOOL)judgeTextFeilMaximumLongWithCurrentContent:(NSString *)currentContent andInputContent:(NSString *)inputContent andMaximumLong:(NSInteger)maximumLong andRange:(NSRange)range;
-(BOOL)judgeLogin:(UIViewController *)view;
#pragma mark 加载 登入失效提示
-(void)loginFailureAlert:(UIViewController *)view;
#pragma mark 根据文子获取宽度
/**
 *
 *根据文子获取宽度
 *
 */
-(CGFloat)returnWithFloat:(NSString *)ss;
#pragma mark -判断用户信息
/**
 *
 *判断用户信息
 *
 */
-(NSInteger)returnIdentityAnduserID:(NSString *)uid;

-(void)actionSheetContent:(NSArray *)content alertViewStyle:(UIViewController *)selfs
           alertViewStyle:(UIAlertActionStyle)style
              cancelBlock:(UIActionSheetBlock)cancelBlock
             confirmBlock:(UIActionSheetBlock)confirmBlock;
/**
 *
 *判断群用户权限  1表示 成员 2表示 管理员 3表示群主
 *
 */
-(CGFloat)returnGroupPeoplePermissions:(NSArray *)AllData;

#pragma mark ----------------操作数据库-------------------
/**
 *  打开数据库
 */
-(BOOL)setDatabaseOpen;
/**
 *  关闭数据库
 */
-(BOOL)setDatabaseClose;
/**
 *  查询
 */
-(NSMutableArray *)setDatabaseEnquiry;

/**
 *  删除
 */
-(BOOL)setDatabaseDeleteWith:(NSString *)Str;
/**
 *  修改
 */
-(BOOL)setDatabaseUpdataWith:(NSString *)Str;
/**
 *  增加
 */
-(BOOL)setDatabaseAddWith:(NSString *)Str;



@end







