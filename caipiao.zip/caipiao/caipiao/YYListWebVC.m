//
//  CJWMarketSpreadViewController.m
//  酷食科技
//
//  Created by apple on 16/9/28.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "YYListWebVC.h"

@interface YYListWebVC ()<UIWebViewDelegate,UIGestureRecognizerDelegate>

@property (strong,nonatomic)UIProgressView *ProgressView;
@property (weak,nonatomic)UIWebView *WebView;
@property (strong,nonatomic)NSTimer *myTimer;
@property (assign,nonatomic)BOOL theBool;

@end

@implementation YYListWebVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    CGFloat progressBarHeight = 2.f;
    CGRect navigationBarBounds = self.navigationController.navigationBar.bounds;
    CGRect barFrame = CGRectMake(0, navigationBarBounds.size.height - progressBarHeight, navigationBarBounds.size.width, progressBarHeight);
    _ProgressView = [[UIProgressView alloc] initWithFrame:barFrame];
    _ProgressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    _ProgressView.progressTintColor =UIColorFromRGB(0xff5501);
    [self.navigationController.navigationBar addSubview:_ProgressView];
    
    //WebView
    UIWebView *MainWebView=[[UIWebView alloc]initWithFrame:CGRectMake(0,0, ScreemW, ScreemH)];
    MainWebView.delegate=self;
    
    NSString *path =[[NSBundle mainBundle] pathForResource:_UrlStr ofType:@"html"];
    
    
    if (_type == 1) {
        NSURL *url = [NSURL URLWithString:_UrlStr];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [MainWebView loadRequest:request];
    }else
    {
        NSURL *url = [NSURL fileURLWithPath:path];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [MainWebView loadRequest:request];
    }
    
    
    _WebView=MainWebView;
    
    [self.view addSubview:MainWebView];
    MainWebView.userInteractionEnabled=YES;
    
    //给webview添加长按手势
    UILongPressGestureRecognizer *longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressed)];
    // longPress.delegate=self;
    [MainWebView addGestureRecognizer:longPress];
}
#pragma mark---处理h5长按手势
-(void)longPressed{
    MHLog(@"-09--9");
}

//- (void)longPressed:(UILongPressGestureRecognizer*)recognizer
//{
//
//    if (recognizer.state != UIGestureRecognizerStateBegan) {
//        return;
//    }
//
//    CGPoint touchPoint = [recognizer locationInView:_WebView];
//
//    NSString *imgURL = [NSString stringWithFormat:@"document.elementFromPoint(%f, %f).src", touchPoint.x, touchPoint.y];
//    NSString *urlToSave = [_WebView stringByEvaluatingJavaScriptFromString:imgURL];
//
//    if (urlToSave.length == 0) {
//        return;
//    }
//
//
//    [self ShowAlter:urlToSave];
//   // [self showImageOptionsWithUrl:urlToSave];
//}
-(void)ShowAlter:(NSString *)ImageUrl
{
    UIAlertController *AlertVC=[UIAlertController alertControllerWithTitle:NSInvalidArgumentException message:nil  preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *Action=[UIAlertAction actionWithTitle:@"保存图片" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self SaveImageOptionsWithUrl:ImageUrl];
    }];
    [AlertVC addAction:Action];
    
}

-(void)SaveImageOptionsWithUrl:(NSString *)urlSave{
    
    dispatch_queue_t Queue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(Queue, ^{
        NSData *IamgeData=[NSData dataWithContentsOfURL:[NSURL URLWithString:urlSave]];
        UIImage *image=[UIImage imageWithData:IamgeData];
        //UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
    });
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [_ProgressView removeFromSuperview];
}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    _ProgressView.progress = 0;
    _theBool = false;
    _myTimer = [NSTimer scheduledTimerWithTimeInterval:0.01667 target:self selector:@selector(timerCallback) userInfo:nil repeats:YES];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    _theBool = true;
}
-(void)timerCallback {
    if (_theBool) {
        if (_ProgressView.progress >= 1) {
            _ProgressView.hidden = true;
            [_myTimer invalidate];
        }
        else {
            _ProgressView.progress += 0.1;
        }
    }
    else {
        _ProgressView.progress += 0.01;
        if (_ProgressView.progress >= 0.95) {
            _ProgressView.progress = 0.95;
        }
    }
}
#pragma mark---保存图片回调代理

-(void)dealloc{
    
}

@end








