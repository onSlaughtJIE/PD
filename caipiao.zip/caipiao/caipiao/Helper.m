//
//  Helper.m
//  酷食科技
//
//  Created by dahaoge on 16/1/27.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "Helper.h"
#import "MBProgressHUD.h"
#import "LoginViewController.h"




#define SYSTEM_VERSION   [[UIDevice currentDevice].systemVersion floatValue]
//屏幕宽度相对iPhone6屏幕宽度的比例
#define KWidth_Scale    [UIScreen mainScreen].bounds.size.width/375.0f

id _publishContent;//类方法中的全局变量这样用（类型前面加static）
@implementation Helper
- (void)alertViewWith:(NSString *)title
              content:(NSString *)message

{
    
}
#pragma mark ------------------------------------------------------------------处理透传消息
-(NSString *)returnGroupMessage:(NSDictionary *)dics andAction:(NSString *)action
{
    NSString *extContent;
    
    int uid = [[[NSUserDefaults standardUserDefaults] objectForKey:@"uid"] intValue];
    
    if([[dics objectForKey:@"tag"] isEqualToString:@"7"])
    {
        //处理进群成功后通知
        if ([[dics objectForKey:@"uid"] intValue] == uid) {
            extContent = @"你已成为新群主";
        }else
        {
            extContent = action;
        }
        
        
    }else if([[dics objectForKey:@"tag"] isEqualToString:@"8"])
    {
        //处理进群成功后通知
        NSArray *arr= [dics objectForKey:@"uid"];
        NSInteger tag = 0;
        for (NSString *uids in arr) {
            if ([uids intValue]==uid) {
                tag = 1;
                break;
            }
        }
        if (tag == 1) {
            //自己
            extContent = @"你已经是新成员了,和大家打个招呼吧!";
        }else
        {
            //其他人
            extContent = action;
        }
        
    }else if([[dics objectForKey:@"tag"] isEqualToString:@"9"])
    {
        /********        对一个人禁言         *************/
        if ([[dics objectForKey:@"uid"] intValue] == uid) {
            //被操作方
            extContent = [NSString stringWithFormat:@"你被管理员禁言%@",[dics objectForKey:@"time"]];
            
        }else if ([[dics objectForKey:@"czuid"] intValue] == uid) {
            //操作方
            extContent = [NSString stringWithFormat:@"%@被你禁言%@",[dics objectForKey:@"bname"],[dics objectForKey:@"time"]];
            
        }else
        {
            //其他人
            extContent = [NSString stringWithFormat:@"%@被管理员%@禁言%@",[dics objectForKey:@"bname"],[dics objectForKey:@"czname"],[dics objectForKey:@"time"]];
        }
        
    }if([[dics objectForKey:@"tag"] isEqualToString:@"10"])
    {
        /********        对一个人取消禁言         *************/
        if ([[dics objectForKey:@"uid"] intValue] == uid) {
            //被操作方
            extContent = @"你被管理员解除禁言";
        }else if ([[dics objectForKey:@"czuid"] intValue] == uid) {
            //操作方
            extContent = [NSString stringWithFormat:@"%@被你解除禁言",[dics objectForKey:@"bname"]];
        }else
        {
            //其他人
            extContent = [NSString stringWithFormat:@"%@被管理员%@解除禁言",[dics objectForKey:@"bname"],[dics objectForKey:@"czname"]];
        }
        
    }if([[dics objectForKey:@"tag"] isEqualToString:@"11"])
    {
        /********        群全体禁言         *************/
        if ([[dics objectForKey:@"czuid"] intValue] == uid) {
            //操作方
            extContent = @"你开启了全员禁言";
        }else
        {
            //其他人
            extContent = @"管理员开启了全员禁言,只有群主和管理员才能发言";
        }
        
    }if([[dics objectForKey:@"tag"] isEqualToString:@"12"])
    {
        /********        群解除全体禁言         *************/
        if ([[dics objectForKey:@"czuid"] intValue] == uid) {
            //操作方
            extContent = @"你关闭了全员禁言";
        }else
        {
            //其他人
            extContent = @"管理员关闭了全员禁言";
        }
        
    }if([[dics objectForKey:@"tag"] isEqualToString:@"15"])
    {
        /********        邀请加群         *************/
        
        // uic --> 加入群的人Uid
        //(czname-> 操作方名字 bname ->(数组)被操作方名字  czuid->操作方Uid  uid -> (数组)被操作方Uid )
        
        //被操作方名字组合
        NSString *busername = @"";
        
        NSArray *arr = [dics objectForKey:@"arr2"];
        
        for (int i=0; i<arr.count; i++) {
            if (i==0) {
                busername = arr[0];
            }else
            {
                busername = [busername stringByAppendingString:[NSString stringWithFormat:@",%@",arr[i]]];
            }
        }
        
        //判断操作方是不是自己
        if([[dics objectForKey:@"czuid"] intValue] == uid)
        {
            //邀请人是自己
            extContent = [NSString stringWithFormat:@"你邀请%@加入了群聊",busername];
        }else
        {
            //邀请人不是自己
            NSArray *arr= [dics objectForKey:@"uid"];
            NSInteger tag = 0;
            for (NSString *uids in arr) {
                if ([uids intValue]==uid) {
                    tag = 1;
                    break;
                }
            }
            if (tag == 1) {
                //自己
                extContent = [NSString stringWithFormat:@"%@邀请你加入了群聊",[dics objectForKey:@"czname"]];
            }else
            {
                //其他人
                extContent = [NSString stringWithFormat:@"%@邀请%@加入了群聊",[dics objectForKey:@"czname"],busername];
            }
        }
    }
    return extContent;
}
//判断相机能否使用


//判断定位服务




#pragma mark -判断手机号
+ (BOOL)judgePhoneNumber:(NSString *)phoneNumber{
    
    //特殊400
    if([phoneNumber containsString:@"400"]){
        return YES;
    }
    if(phoneNumber.length!=11)
        return NO;
    NSString *phonenumber = @"^((13[0-9])|(147)|(15[0-9])|(17[0-8])|(18[0-9]))\\d{8}|(1705)\\d{7}$";
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self matches %@", phonenumber];
    BOOL result = [predicate evaluateWithObject:phoneNumber];
    
    return result;
}

//企业电话
+(BOOL)JudgeEnterprisePhoneNumber:(NSString *)EnterPriseNumber{
    //特殊400
    if([EnterPriseNumber containsString:@"400"]){
        return YES;
    }
    
    NSString *phonenumber = @"^0(10|2[0-5789]|\\d{3})\\d{7,8}$";
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self matches %@", phonenumber];
    BOOL result = [predicate evaluateWithObject:EnterPriseNumber];
    BOOL PhoneResult= [Helper judgePhoneNumber:EnterPriseNumber];
    
    //符合一个就行
    if(result||PhoneResult){
        return  YES;
    }else{
        return  NO;
    }
}

#pragma mark--判断身份证号
+(BOOL)CheckingID:(NSString *)IDNumber
{
    if(IDNumber.length!=18)
        return NO;
    
    NSMutableArray *IDArray = [NSMutableArray array];
    // 遍历身份证字符串,存入数组中
    for (int i = 0; i < 18; i++) {
        NSRange range = NSMakeRange(i, 1);
        NSString *subString = [IDNumber substringWithRange:range];
        [IDArray addObject:subString];
    }
    // 系数数组
    NSArray *coefficientArray = [NSArray arrayWithObjects:@"7", @"9", @"10", @"5", @"8", @"4", @"2", @"1", @"6", @"3", @"7", @"9", @"10", @"5", @"8", @"4", @"2", nil];
    // 余数数组
    NSArray *remainderArray = [NSArray arrayWithObjects:@"1", @"0", @"X", @"9", @"8", @"7", @"6", @"5", @"4", @"3", @"2", nil];
    // 每一位身份证号码和对应系数相乘之后相加所得的和
    int sum = 0;
    for (int i = 0; i < 17; i++) {
        int coefficient = [coefficientArray[i] intValue];
        int ID = [IDArray[i] intValue];
        sum += coefficient * ID;
    }
    // 这个和除以11的余数对应的数
    NSString *str = remainderArray[(sum % 11)];
    // 身份证号码最后一位
    NSString *string = [IDNumber substringFromIndex:17];
    // 如果这个数字和身份证最后一位相同,则符合国家标准,返回YES
    if ([str isEqualToString:string]) {
        return YES;
    } else {
        return NO;
    }
}


+(NSURL *)GetImageUrlWithStr:(NSString *)ImageStr
{
    if(ImageStr.length>1){
        NSString *FistStr=[ImageStr substringToIndex:1];
        NSURL *url;
        if([FistStr isEqualToString:@"h"]){
            url=[NSURL URLWithString:ImageStr];
        }else{
            NSString *UrlStr=[NSString stringWithFormat:@"%@%@",MINEDUANKOU,ImageStr];
            url=[NSURL URLWithString:UrlStr];
        }
        return url;
    }else{
        return [NSURL URLWithString:ImageStr];
    }
    
}


+(CGFloat)GetCellLeftInterVal
{
    CGFloat interval;
    if(ScreemW==414)
    {
        interval=20;
    }else{
        interval=15;
    }
    return interval;
}
+(NSString *)TransformTimeDate:(id)DateStr
{
    NSTimeInterval timeI=[DateStr intValue];
    
    NSDate *date=[NSDate dateWithTimeIntervalSince1970:timeI];
    NSDateFormatter *Fomatter=[[NSDateFormatter alloc]init];
    [Fomatter setDateFormat:@"MM-dd HH:mm"];
    
    return [Fomatter stringFromDate:date];
}
+(NSString *)TransformTimeDateTOYead:(id)DateStr
{
    NSTimeInterval timeI=[DateStr intValue];
    
    NSDate *date=[NSDate dateWithTimeIntervalSince1970:timeI];
    NSDateFormatter *Fomatter=[[NSDateFormatter alloc]init];
    [Fomatter setDateFormat:@"YYYY-MM-dd"];
    
    return [Fomatter stringFromDate:date];
}
+(NSString *)allTimeIntervalWith:(double)beTime
{
    NSDate * beDate = [NSDate dateWithTimeIntervalSince1970:beTime];
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"HH:mm"];
    
    [df setDateFormat:@"dd"];
    [df setDateFormat:@"yyyy-MM-dd HH:mm"];
    return [df stringFromDate:beDate];
}
+(NSString *)TimeIntervalWith:(NSString *)TimeStr
{
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSDate *talkdate=[formatter dateFromString:TimeStr];
    
    NSDate *nowdate=[NSDate new];
    NSTimeInterval intervalTime=[nowdate timeIntervalSinceDate:talkdate];
    
    // int month=((int)intervalTime)/(3600*24*30);
    int days=((int)intervalTime)/(3600*24);
    int hours=((int)intervalTime)%(3600*24)/3600;
    int minute=((int)intervalTime)%(3600*24)/60;
    
    NSString *dateContent;
    //    if(month!=0){
    //        dateContent = [NSString stringWithFormat:@"%i%@",month,@"个月前"];
    //    }
    if(days>1){
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"MM-dd HH:mm"];
        dateContent = [formatter stringFromDate:talkdate];
    }else if(days==1){
        dateContent = @"昨天";
    }else if(hours!=0){
        dateContent = [NSString stringWithFormat:@"%i%@",hours,@"小时前"];
    }else if(minute!=0){
        dateContent =[NSString stringWithFormat:@"%i%@",minute,@"分钟前"];
    }else{
        dateContent=@"刚刚";
    }
    return dateContent;
}
+(UIImage *)createImageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}
+(NSString *)GetProvinceUidWithStr:(NSString *)Province
{
    //省份id
    NSString *ShengFenId;
    NSString *path=[[NSBundle mainBundle]pathForResource:@"省份列表check.plist" ofType:nil];
    NSArray *CityPlist=[NSArray arrayWithContentsOfFile:path];
    for(NSDictionary *dic in CityPlist)
    {
        if([dic[@"categoryname"] isEqualToString:Province])
        {
            ShengFenId=dic[@"uid"];
        }
    }
    return ShengFenId;
}
+(NSString *)GetCityUidWithStr:(NSString *)City
{
    //城市
    NSString *CityUid;
    NSString *path=[[NSBundle mainBundle]pathForResource:@"城市列表check.plist" ofType:nil];
    NSArray *CityPlist=[NSArray arrayWithContentsOfFile:path];
    for(NSDictionary *dic in CityPlist)
    {
        if([dic[@"categoryname"] isEqualToString:City])
        {
            CityUid=dic[@"uid"];
        }
    }
    return CityUid;
}
+(NSArray *)GetProvinceArr{
    NSString *path=[[NSBundle mainBundle]pathForResource:@"省份列表.plist" ofType:nil];
    NSArray *CityPlist=[NSArray arrayWithContentsOfFile:path];
    return CityPlist;
}
+(NSDictionary *)GetCityDic
{
    NSString *path=[[NSBundle mainBundle]pathForResource:@"城市列表.plist" ofType:nil];
    NSDictionary *CityDic=[NSDictionary dictionaryWithContentsOfFile:path];
    return CityDic;
}

#pragma mark 加载
/**********************          行业圈              **************************/
/*圈子话题帖子内容处理*/
+ (NSString *) returnUploadContent:(NSString *)content
{
    if (content.length >65) {
        return [NSString stringWithFormat:@"%@......",[content substringToIndex:65]];
    }else
    {
        return content;
    }
}
+ (NSString *) returnUploadTitle:(NSString *)content
{
    if (content.length >36) {
        return [NSString stringWithFormat:@"%@......",[content substringToIndex:36]];
    }else
    {
        return content;
    }
}
//根据文子获取高度

//根据文子获取高度
+(CGFloat)returnheithtContent:(NSString *)content andWith:(NSInteger)with andSize:(NSInteger)size
{
    CGSize titleSize = [content boundingRectWithSize:CGSizeMake(with, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:size]} context:nil].size;
    return titleSize.height;
}


//根据文子获取高度 没有适配文字字体大下


/*处理返回应该显示的时间*/
+ (NSString *)distanceTimeWithBeforeTime:(double)beTime
{
    
    NSTimeInterval nowtime = [[NSDate date]timeIntervalSince1970];
    int distanceTime = nowtime - beTime;
    
    NSString * distanceStr;

    NSDate * beDate = [NSDate dateWithTimeIntervalSince1970:beTime];
    NSDateFormatter * df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"HH:mm"];
    NSString * timeStr = [df stringFromDate:beDate];
    
    [df setDateFormat:@"dd"];
    NSString * nowDay = [df stringFromDate:[NSDate date]];
    NSString * lastDay = [df stringFromDate:beDate];
    
   // MHLog(@"---%d-",distanceTime);
    if (distanceTime < 60) {//小于一分钟
        distanceStr = @"刚刚";
    }
    else if (distanceTime < 60*60) {//时间小于一个小时
        distanceStr = [NSString stringWithFormat:@"%ld分钟前",(long)distanceTime/60];
    }
    else if(distanceTime < 24*60*60 && [nowDay integerValue] == [lastDay integerValue]){//时间小于一天
       // [df setDateFormat:@"HH"];
        distanceStr = [NSString stringWithFormat:@"%d小时前",distanceTime/3600];
        //NSLog(@"--%@--",distanceStr);
        
//        if ([distanceStr intValue]-8>9) {
//           // [df setDateFormat:@"HH小时前"];
////            distanceStr = [df stringFromDate:beDate];
//        }else{
////            [df setDateFormat:@"H小时前"];
////            distanceStr = [df stringFromDate:beDate];
//        }
//        distanceStr=[NSString stringWithFormat:@"%d小时前",[distanceStr intValue]-8];
    }
    else if(distanceTime< 24*60*60*2 && [nowDay integerValue] != [lastDay integerValue]){
        
        if ([nowDay integerValue] - [lastDay integerValue] == 1 || ([lastDay integerValue] - [nowDay integerValue] > 10 && [nowDay integerValue] == 1)) {
            
            distanceStr = [NSString stringWithFormat:@"昨天 %@",timeStr];
        }
        else{
            if(distanceTime/24/60/60/30>9)
            {
                if ((distanceTime-distanceTime/24/60/60/30)/24/60/60>9) {
                    [df setDateFormat:@"MM月dd日 HH:mm"];
                    distanceStr = [df stringFromDate:beDate];
                }else
                {
                    [df setDateFormat:@"MM月d日 HH:mm"];
                    distanceStr = [df stringFromDate:beDate];
                }
            }else
            {
                [df setDateFormat:@"dd"];
                distanceStr = [df stringFromDate:beDate];
                NSLog(@"-----%@",distanceStr);
                
                if ([distanceStr intValue]>9) {
                    [df setDateFormat:@"M月dd日 HH:mm"];
                    distanceStr = [df stringFromDate:beDate];
                }else
                {
                    [df setDateFormat:@"M月d日 HH:mm"];
                    distanceStr = [df stringFromDate:beDate];
                }
            }
        }
        
    }
    else if(distanceTime < 24*60*60*365){
        //判断月份 天数
        
        
        
        if(distanceTime/24/60/60/30>9)
        {
            if ((distanceTime-distanceTime/24/60/60/30)/24/60/60>9) {
                [df setDateFormat:@"MM月dd日 HH:mm"];
                distanceStr = [df stringFromDate:beDate];
            }else
            {
                [df setDateFormat:@"MM月d日 HH:mm"];
                distanceStr = [df stringFromDate:beDate];
            }
        }else
        {
            [df setDateFormat:@"dd"];
            distanceStr = [df stringFromDate:beDate];
            
            if ([distanceStr intValue]>9) {
                [df setDateFormat:@"M月dd日 HH:mm"];
                distanceStr = [df stringFromDate:beDate];
            }else
            {
                [df setDateFormat:@"M月d日 HH:mm"];
                distanceStr = [df stringFromDate:beDate];
            }
        }
        
        
    }
    else{
        [df setDateFormat:@"yyyy-MM-dd HH:mm"];
        distanceStr = [df stringFromDate:beDate];
    }
    
    return distanceStr;
}
/**********************          行业圈              **************************/

+ (void)shareWithContent:(id)publishContent{
    _publishContent = publishContent;
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    
    UIView *blackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];
    blackView.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.85];
    blackView.tag = 440;
    [window addSubview:blackView];
    
    UIView *shareView = [[UIView alloc] initWithFrame:CGRectMake((screenW-300*KWidth_Scale)/2.0f, (screenH-270*KWidth_Scale)/2.0f, 300*KWidth_Scale, 270*KWidth_Scale)];
    shareView.backgroundColor = [UIColor colorWithRed:0.9647 green:0.9647 blue:0.9647 alpha:1.0];
    shareView.tag = 441;
    [window addSubview:shareView];
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, shareView.width, 45*KWidth_Scale)];
    titleLabel.text = @"分享到";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.font = [UIFont systemFontOfSize:15*KWidth_Scale];
    titleLabel.textColor = [UIColor colorWithRed:0.1647 green:0.1647 blue:0.1647 alpha:1.0];
    titleLabel.backgroundColor = [UIColor clearColor];
    [shareView addSubview:titleLabel];
    
    NSArray *btnImages = @[@"qq好友", @"qq空间", @"纳食圈", @"微信好友", @"朋友圈", @"新浪微博"];
    NSArray *btnTitles = @[@"QQ好友", @"QQ空间", @"纳食圈", @"微信好友", @"朋友圈", @"新浪微博"];
    for (NSInteger i=0; i<6; i++) {
        CGFloat top = 0.0f;
        if (i<4) {
            top = 10*KWidth_Scale;
            
        }else{
            top = 90*KWidth_Scale;
        }
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(10*KWidth_Scale+(i%4)*70*KWidth_Scale, CGRectGetMaxY(titleLabel.frame)+top, 70*KWidth_Scale, 70*KWidth_Scale)];
        [button setImage:[UIImage imageNamed:btnImages[i]] forState:UIControlStateNormal];
        [button setTitle:btnTitles[i] forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:11*KWidth_Scale];
        button.titleLabel.textAlignment = NSTextAlignmentCenter;
        [button setTitleColor:[UIColor colorWithRed:0.1647 green:0.1647 blue:0.1647 alpha:1.0] forState:UIControlStateNormal];
        
        [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
        [button setContentVerticalAlignment:UIControlContentVerticalAlignmentTop];
        [button setImageEdgeInsets:UIEdgeInsetsMake(0, 15*KWidth_Scale, 30*KWidth_Scale, 15*KWidth_Scale)];
        if (SYSTEM_VERSION >= 8.0f) {
            [button setTitleEdgeInsets:UIEdgeInsetsMake(45*KWidth_Scale, -40*KWidth_Scale, 5*KWidth_Scale, 0)];
        }else{
            [button setTitleEdgeInsets:UIEdgeInsetsMake(45*KWidth_Scale, -90*KWidth_Scale, 5*KWidth_Scale, 0)];
        }
        
        button.tag = 331+i;
        [button addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [shareView addSubview:button];
    }
    
    UIButton *cancleBtn = [[UIButton alloc] initWithFrame:CGRectMake((shareView.width-100*KWidth_Scale)/2.0f, shareView.height-40*KWidth_Scale-18*KWidth_Scale, 100*KWidth_Scale, 40*KWidth_Scale)];
    //[cancleBtn setBackgroundImage:[UIImage imageNamed:@"alert_error_icon"] forState:UIControlStateNormal];
    [cancleBtn setTitle:@"取消分享" forState:UIControlStateNormal];
    [cancleBtn setTitleColor:[UIColor colorWithRed:0.1333 green:0.1333 blue:0.1333 alpha:1.0] forState:UIControlStateNormal];
    //[cancleBtn setBackgroundColor:[UIColor blueColor]];
    cancleBtn.tag = 337;
    [cancleBtn addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [shareView addSubview:cancleBtn];
    
    //为了弹窗不那么生硬，这里加了个简单的动画
    shareView.transform = CGAffineTransformMakeScale(1/300.0f, 1/270.0f);
    blackView.alpha = 0;
    [UIView animateWithDuration:0.35f animations:^{
        shareView.transform = CGAffineTransformMakeScale(1, 1);
        blackView.alpha = 1;
    } completion:^(BOOL finished) {
        
    }];
}



+ (AFHTTPSessionManager *)helperForManager{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"application/x-javascript",nil];
    return manager;
}

@end
@implementation UIView (shuaxin)


@end

@implementation UIView (zishiying)

- (CGRect)getWidth:(NSString *)text
         WithHight:(CGFloat)hight
         WithFrame:(CGRect)originalFrame{
    CGRect rect = [text boundingRectWithSize:CGSizeMake(0, hight) options:NSStringDrawingUsesFontLeading |  NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil];
    CGRect frame = originalFrame;
    frame.size.width = rect.size.width +40;
    return frame;
}

- (CGRect)getHight:(NSString *)text
         WithWidth:(CGFloat)width
         WithFrame:(CGRect)originalFrame{
    CGRect rect = [text boundingRectWithSize:CGSizeMake(width, 0) options:NSStringDrawingUsesFontLeading |  NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil];
    CGRect frame = originalFrame;
    frame.size.width = rect.size.width ;
    return frame;
}

#pragma mark -------------------------------------------------------------------添加间距
-(NSMutableAttributedString *)addSpacingWithContent:(NSString *)content
{
    NSMutableAttributedString * attributedString1 = [[NSMutableAttributedString alloc] initWithString:content];
    NSMutableParagraphStyle * paragraphStyle1 = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle1 setLineSpacing:spacingFlaot];
    [attributedString1 addAttribute:NSParagraphStyleAttributeName value:paragraphStyle1 range:NSMakeRange(0, [content length])];
    return attributedString1;
}

@end

@implementation UIViewController (alert)
-(void)requestNoNetworkTips:(UIView *)view andContent:(NSString *)content
{
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.mode = MBProgressHUDModeText;
    
    hud.labelText = @"温馨提示:";
    hud.userInteractionEnabled = NO;
    hud.margin = 10.f;
    hud.detailsLabelFont = [UIFont systemFontOfSize:14 weight:20];
    hud.labelColor = [UIColor colorWithRed:0/255.0 green:173/255.0 blue:255/255.0 alpha:1.0];
    hud.minShowTime = 0.001;
    hud.detailsLabelText = content;
    hud.yOffset = 150.f;
    hud.removeFromSuperViewOnHide = YES;
    [hud hide:YES afterDelay:3];
}
- (void)alertActionWith:(NSString *)title
                content:(NSString *)message
             alertStyle:(UIAlertControllerStyle)style
            cancelBlock:(UIActionSheetBlock)cancelBlock
                 isSure:(BOOL)sure;{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:style];
    
    
    
    [self showDetailViewController:alert sender:nil];
    if (sure) {
        UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [alert dismissViewControllerAnimated:YES completion:nil];
            cancelBlock(1);
        }];
        alert.view.tintColor = sxyColor;
        [alert addAction:alertAction];
        
    }else{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [alert dismissViewControllerAnimated:YES completion:nil];
        });
    }
}
- (void)alertActionWith:(NSString *)title
                content:(NSString *)message
             alertStyle:(UIAlertControllerStyle)style
                 isSure:(BOOL)sure;{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:style];
    
    [self showDetailViewController:alert sender:nil];
    if (sure) {
        UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            [alert dismissViewControllerAnimated:YES completion:nil];
            
        }];
        alert.view.tintColor = sxyColor;
        [alert addAction:alertAction];
        
    }else{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [alert dismissViewControllerAnimated:YES completion:nil];
        });
    }
    
}


- (UIImageView *)findHairlineImageViewUnder:(UIView *)view {
    if ([view isKindOfClass:UIImageView.class] && view.bounds.size.height <= 1.0) {
        return (UIImageView *)view;
    }
    for (UIView *subview in view.subviews) {
        
        UIImageView *imageView = [self findHairlineImageViewUnder:subview];
        if (imageView) {
            return imageView;
        }
    }
    return nil;
}



- (void)addObserveForKeyboardWithObserve:(UIViewController *)observe{
    //    //观察键盘是否将要出现(系统通知)
    //    [[NSNotificationCenter defaultCenter] addObserver:observe selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillShowNotification object:nil];
    //    //观察键盘是否将要消失(系统通知)
    //    [[NSNotificationCenter defaultCenter] addObserver:observe selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark -监听键盘事件
-(void)keyboardWillChangeFrame:(NSNotification *)notification
{
    float duration = [notification.userInfo[@"UIKeyboardAnimationDurationUserInfoKey"] floatValue];
    if (notification.name == UIKeyboardWillShowNotification) {
        
        CGRect rect = [notification.userInfo[@"UIKeyboardFrameEndUserInfoKey"] CGRectValue];
        float height = rect.size.height - 200 ;
        //动画改编当前的 根视图的偏移
        [UIView animateWithDuration:duration animations:^{
            self.view.frame = CGRectMake(self.view.frame.origin.x, -height, self.view.frame.size.width, self.view.frame.size.height);
        }];
    }else{
        
        //动画改编当前的 根视图的偏移
        [UIView animateWithDuration:duration animations:^{
            self.view.frame = CGRectMake(self.view.frame.origin.x, 0, self.view.frame.size.width, self.view.frame.size.height);
        }];
    }
}
#pragma mark ------------------------------------------------------------------判断输入框最大输入长度
-(BOOL)judgeTextFeilMaximumLongWithCurrentContent:(NSString *)currentContent andInputContent:(NSString *)inputContent andMaximumLong:(NSInteger)maximumLong andRange:(NSRange)range
{
    NSString *strings = [NSString stringWithFormat:@"%@%@",currentContent,inputContent];
    
    if (range.location+[self convertToInt:strings] >maximumLong)
    {
        if (range.length > 0) {
            return YES;
        }else
        {
            return NO;
        }
    }else
    {
        return YES;
    }
}

#pragma mark ------------------------------------------------------------------获取字符串中文字长度
- (int)convertToInt:(NSString *)strtemp//判断中英混合的的字符串长度
{
    int strlength = 0;
    for (int i=0; i< [strtemp length]; i++) {
        int a = [strtemp characterAtIndex:i];
        if( a > 0x4e00 && a < 0x9fff) { //判断是否为中文
            strlength += 1;
        }
    }
    return strlength;
}

#pragma mark 加载 判断登入
-(BOOL)judgeLogin:(UIViewController *)view
{
    
    
    NSString *token =[userDefault objectForKey:@"token"];
    if (token.length == 0) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请先登录" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            LoginViewController *loginVC = [sb instantiateViewControllerWithIdentifier:@"LoginViewController"];
            [view.navigationController pushViewController:loginVC animated:YES];
            
        }];
        UIAlertAction *actions = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alert addAction:action];
        [alert addAction:actions];
        [view presentViewController:alert animated:YES completion:nil];
        
        
        /*
         if ([[userDefault objectForKey:@"islogin"] isEqualToString:@"1"]) {
         UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请先登录" preferredStyle:UIAlertControllerStyleAlert];
         
         UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
         
         UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
         LoginViewController *loginVC = [sb instantiateViewControllerWithIdentifier:@"LoginViewController"];
         [view.navigationController pushViewController:loginVC animated:YES];
         
         }];
         UIAlertAction *actions = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
         
         }];
         [alert addAction:action];
         [alert addAction:actions];
         [view presentViewController:alert animated:YES completion:nil];
         }else
         {
         YYInvitationView *invitationView = [[YYInvitationView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];
         invitationView.vc = view;
         UIWindow *win = [[[UIApplication sharedApplication] windows] firstObject];
         
         [win addSubview:invitationView];
         }
         
        */
        
        return NO;
    }else
    {
        return YES;
    }
    return YES;
}
#pragma mark 加载 登入失效提示
-(void)loginFailureAlert:(UIViewController *)view
{
    [userDefault setObject:@"" forKey:@"token"];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请先登录" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        LoginViewController *loginVC = [sb instantiateViewControllerWithIdentifier:@"LoginViewController"];
        [view.navigationController pushViewController:loginVC animated:YES];
        
    }];
    UIAlertAction *actions = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alert addAction:action];
    [alert addAction:actions];
    [view presentViewController:alert animated:YES completion:nil];
    
    
    /*
     
     if ([[userDefault objectForKey:@"islogin"] isEqualToString:@"1"]) {
     UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请先登录" preferredStyle:UIAlertControllerStyleAlert];
     
     UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
     
     UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
     LoginViewController *loginVC = [sb instantiateViewControllerWithIdentifier:@"LoginViewController"];
     [view.navigationController pushViewController:loginVC animated:YES];
     
     }];
     UIAlertAction *actions = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
     
     }];
     [alert addAction:action];
     [alert addAction:actions];
     [view presentViewController:alert animated:YES completion:nil];
     
     }else
     {
     YYInvitationView *invitationView = [[YYInvitationView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];
     invitationView.vc = view;
     UIWindow *win = [[[UIApplication sharedApplication] windows] firstObject];
     
     [win addSubview:invitationView];
     }
     */
}
#pragma mark 加载
-(void)startRequests:(UIView *)view andContent:(NSString *)content
{
    MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    //设置对话框文字
    HUD.labelText = content;
    HUD.alpha = 0.5;
    HUD.labelFont = [UIFont systemFontOfSize:15];
    
}
-(void)startRequests:(UIView *)view
{
    MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    //设置对话框文字
    HUD.labelText = @"加载中...";
    HUD.alpha = 0.5;
    HUD.labelFont = [UIFont systemFontOfSize:15];
    
}
-(void)startRequests:(UIView *)view Message:(NSString *)ShowMessage
{
    MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    //设置对话框文字
    HUD.labelText = ShowMessage;
}

-(void)endRequests:(UIView *)view
{
    [MBProgressHUD hideHUDForView:view animated:YES];
}
//根据文子获取宽度
-(CGFloat)returnWithFloat:(NSString *)ss
{
    CGSize titleSize = [ss boundingRectWithSize:CGSizeMake(screenW-40, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil].size;
    return titleSize.width+80;
}

#pragma mark -判断用户信息
-(NSInteger)returnIdentityAnduserID:(NSString *)uid
{
    NSUserDefaults *userdDefaults = [[NSUserDefaults standardUserDefaults] objectForKey:@"uid"];
    if ([uid isEqualToString:[userdDefaults objectForKey:@"uid"]]) {
        return 1;
    }
    return 0;
    
}
+(void)actionSheetContent:(NSArray *)content alertViewStyle:(UIViewController *)selfs
           alertViewStyle:(UIAlertActionStyle)style
              cancelBlock:(UIActionSheetBlock)cancelBlock
             confirmBlock:(UIActionSheetBlock)confirmBlock
{
    UIAlertController *sheetController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleAlert];
    for (NSString *title in content) {
        UIAlertAction *deleteAction = [UIAlertAction actionWithTitle:title style:style handler:^(UIAlertAction *action) {
            for (int i=0; i<content.count; i++) {
                if ([content[i] isEqualToString:action.title]) {
                    cancelBlock(i);
                }
            }
            
        }];
        [sheetController addAction:deleteAction];
    }
    [selfs presentViewController:sheetController animated:YES completion:nil];
}
#pragma mark ------------------------------------------------------------------判断群组职位

#pragma mark ----------------操作数据库-------------------

/**
 *  查询
 */

-(NSMutableArray *)setDatabaseEnquiry
{
    return nil;
}



@end










