//
//  InvestmentMainPage.m
//  
//
//  Created by 挣钱宝 on 15/10/16.
//
//

#import "InvestmentMainPage.h"
#import "GTCommontHeader.h"
#import "YYFistDetailVC.h"
@interface InvestmentMainPage ()
{
    UITableView *_mainDateTB;     //理财页布局
    NSArray * _investmerntArray;  //title
    NSArray * _requestArray;      //请求区分
    NSTimer *_time;
}
@end

@implementation InvestmentMainPage

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"首页";
    _investmerntArray = @[@"双色球",@"大乐透",@"时时彩",@"七星彩",@"福彩3D",@"11选5",@"排列3",@"排列5",@"联系我们"];
    _requestArray = @[@"双色球",@"大乐秀",@"时时彩",@"七星彩",@"福彩三地",@"11选5",@"排列三",@"排列五",@"联系我们"];
    
    //轮播图
    [self loadScrollviewImage];
    //分类
    [self layoutMainPage];
    //判断版本号
    self.view.backgroundColor = [UIColor whiteColor];
}

-(void)layoutMainPage
{
    
    UIScrollView *main_SV = [[UIScrollView alloc] initWithFrame:GTRectMake(5, 186, 310, 350)];
    main_SV.delegate = self;
    main_SV.contentSize = CGSizeMake(0, 310);
    main_SV.backgroundColor = [UIColor whiteColor];
    main_SV.showsHorizontalScrollIndicator = NO;
    main_SV.showsVerticalScrollIndicator = YES;
    [self.view addSubview:main_SV];
    UIView *mainView= [[UIView alloc] initWithFrame:GTRectMake(0, 0, 310, 350)];
    [self loadButton:mainView];
    mainView.backgroundColor = [UIColor whiteColor];
    [main_SV addSubview:mainView];
}
#pragma mark  创建主页button按钮
-(void)loadButton:(UIView *)view
{
    
    for(int i=0;i<8;i++)
    {
        
        
        UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem];
        button.frame=GTRectMake(310/3*(i%3), 310/3*(i/3), 310/3, 310/3);
        //[button.layer setBorderWidth:0.5];
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        //button.layer.borderColor = BGCOLOR.CGColor;
        button.tag = i+1;
        UIImageView *indexImage =[[UIImageView alloc] initWithImage:[UIImage imageNamed:_investmerntArray[i]]];
        indexImage.frame = CGRectMake(button.frame.size.width-GTFixWidthFlaot(70), button.frame.size.height-GTFixWidthFlaot(80), GTFixWidthFlaot(40), GTFixWidthFlaot(40));
        [button addSubview:indexImage];
        UILabel *title = [[UILabel alloc] init];
        title.frame = CGRectMake(button.frame.size.width-GTFixWidthFlaot(79), button.frame.size.height-GTFixWidthFlaot(40), GTFixWidthFlaot(60), GTFixWidthFlaot(30));
        
        title.font = [UIFont systemFontOfSize:GTFondWidthFlaot(12)];
        [title setTextAlignment:NSTextAlignmentCenter];
        title.text = _investmerntArray[i];
        title.textColor = BGCOLORZT;
        [button addSubview:title];
        [view addSubview:button];
        if(i == 0)
        {
            title.textColor = sxyColor;
            UIImageView *indexImages =[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pages-image-rt"]];
            indexImages.frame = CGRectMake(button.frame.size.width-GTFixWidthFlaot(60), 0, GTFixWidthFlaot(60), GTFixWidthFlaot(60));
            [button addSubview:indexImages];
            UILabel *lb = [[UILabel alloc] initWithFrame: CGRectMake(button.frame.size.width-GTFixWidthFlaot(34), 0, GTFixWidthFlaot(45), GTFixWidthFlaot(45))];
            lb.font = [UIFont systemFontOfSize:8];
            lb.text = @"热投";
            lb.font = [UIFont fontWithName:@"Helvetica-Bold" size:GTFixWidthFlaot(12)];
            lb.transform = CGAffineTransformMakeRotation(M_PI*3/12);
            lb.textColor = [UIColor whiteColor];
            [button addSubview:lb];
            
        }
        if (i<4) {
            UIView *views = [[UIView alloc] initWithFrame:GTRectMake(0, 310/3*i,310, 1)];
            views.backgroundColor = BGCOLORBORDER;
            [view addSubview:views];
            UIView *viewss = [[UIView alloc] initWithFrame:GTRectMake(310/3*i, 0,1, 318)];
            viewss.backgroundColor = BGCOLORBORDER;
            [view addSubview:viewss];
        }
    }
   // view.layer.borderWidth = 1;
    
   // view.layer.borderColor = [[UIColor redColor] CGColor];
}
#pragma mark  创建主页button事件
-(void)buttonClick:(UIButton *)bt
{
    if (bt.tag!= 8) {
               self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        self.hidesBottomBarWhenPushed = YES;
        self.hidesBottomBarWhenPushed = NO;
    }else
    {
        self.hidesBottomBarWhenPushed = YES;
        
        self.hidesBottomBarWhenPushed = NO;
    }
    YYFistDetailVC *fist = [YYFistDetailVC new];
    fist.title = _investmerntArray[bt.tag-1];
    fist.type = bt.tag-1;
    [self.navigationController pushViewController:fist animated:YES];
}
#pragma mark 设置滚动广告
-(void)loadScrollviewImage
{
    UIScrollView *img_SV = [[UIScrollView alloc] initWithFrame:GTRectMake(0, 0, 320, 180)];
    img_SV.delegate = self;
    img_SV.tag = 23;
    for (int i = 0; i<3; i++) {
        UIImageView *imgView=[[UIImageView alloc]initWithFrame:CGRectMake(GTFixWidthFlaot(320)*i, 0, GTFixWidthFlaot(320), GTFixHeightsFlaot(130))];
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"pages-%d.png",i+1]];
        [img_SV addSubview:imgView];
    }
    img_SV.tag = 20;
    img_SV.contentSize = CGSizeMake(GTFixWidthFlaot(320)*3, 0);
    img_SV.pagingEnabled = YES;
    img_SV.contentOffset = CGPointMake(0, 0);
    img_SV.showsHorizontalScrollIndicator = NO;
    img_SV.showsVerticalScrollIndicator = NO;
    [self.view addSubview:img_SV];
    //设置滚动点
    UIPageControl *page = [[UIPageControl alloc] initWithFrame:GTRectMake(0, 166, 320, 10)];
    page.tag=21;
    page.numberOfPages = 3;
    page.currentPage = 0;
    page.pageIndicatorTintColor = BGCOLORBG;
    page.currentPageIndicatorTintColor = BGColor;
    [page addTarget:self action:@selector(changeClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:page];
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(runTimePage) userInfo:nil repeats:YES];
}
// pagecontrol 选择器的方法
- (void)turnPage
{
    UIScrollView *sc=(UIScrollView *)[self.view viewWithTag:20];
    UIPageControl *pageControl = (UIPageControl *)[self.view viewWithTag:21];
    NSInteger page = pageControl.currentPage; // 获取当前的page
    [sc scrollRectToVisible:CGRectMake(GTFixWidthFlaot(320)*(page+0),0,GTFixWidthFlaot(320),130) animated:NO]; // 触摸pagecontroller那个点点 往后翻一页 +1
}
// 定时器 绑定的方法
- (void)runTimePage
{
    UIPageControl *pageControl = (UIPageControl *)[self.view viewWithTag:21];
    NSInteger page = pageControl.currentPage; // 获取当前的page
    page++;
    page = page > 2 ? 0 : page ;
    pageControl.currentPage = page;
    [self turnPage];
}
-(void)changeClick:(UIPageControl *)page
{
    NSInteger num = page.currentPage;
    UIScrollView *sc=(UIScrollView *)[self.view viewWithTag:20];
    
    //sc.contentOffset=CGPointMake(200*num, 0);
    [sc setContentOffset:CGPointMake(GTFixWidthFlaot(320)*num, 0) animated:YES];
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView.tag == 23) {
        int num = scrollView.contentOffset.x/GTFixWidthFlaot(320);
        UIPageControl *page = (UIPageControl *)[self.view viewWithTag:21];
        page.currentPage = num;
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
