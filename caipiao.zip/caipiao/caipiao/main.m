//
//  main.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
