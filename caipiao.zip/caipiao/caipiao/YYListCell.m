//
//  YYListCell.m
//  sasa
//
//  Created by 挣钱宝 on 17/4/15.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYListCell.h"
@interface YYListCell()

@end

@implementation YYListCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andTypeNummber:(NSInteger)lbNummber andcolorNummber:(NSInteger)colorNummber
{
    if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUpWithNummber:lbNummber andcolorNummber:colorNummber];
    }
    return self;
}

-(void)setUpWithNummber:(NSInteger)lbNummber andcolorNummber:(NSInteger)colorNummber
{
    for (int i=0; i<lbNummber; i++) {
        
        if (i<2) {
            UILabel *lb = [[UILabel alloc] init];
            lb.font = [UIFont systemFontOfSize:14];
            if (i==0) {
                lb.frame = CGRectMake(20, 15, 50, 20);
                lb.font = [UIFont systemFontOfSize:14];
                lb.textColor = UIColorFromRGB(0x222222);
            }else
            {
                lb.frame = CGRectMake(80, 15, 250, 20);
                lb.font = [UIFont systemFontOfSize:12];
                lb.textColor = UIColorFromRGB(0x666666);
            }
            lb.tag = i+10;
            [self addSubview:lb];
        }
        UILabel *colorLB = [[UILabel alloc] initWithFrame:CGRectMake(20+31*i, 40, 26, 26)];
        if (i>colorNummber) {
            colorLB.backgroundColor = UIColorFromRGB(0x6EA5E3);
        }else
        {
            colorLB.backgroundColor = UIColorFromRGB(0xDD420F);
        }
        colorLB.textColor = [UIColor whiteColor];
        colorLB.tag = i+1;
        colorLB.textAlignment = NSTextAlignmentCenter;
        colorLB.font = [UIFont systemFontOfSize:15];
        colorLB.layer.cornerRadius = 13;
        colorLB.layer.masksToBounds = YES;
        [self addSubview:colorLB];
        
    }
}
-(void)setDataDic:(NSDictionary *)dataDic
{
    //NSArray *content = [dataDic objectForKey:@"titleContent"];
    NSArray *dataArrAll = dataDic[@"payload3"];
    if (dataArrAll.count == 0) {
        dataArrAll =dataDic[@"results"];
    }
    UILabel *lb = [self viewWithTag:11];
    lb.text = dataDic[@"issueText"];
    
    NSArray *dataArrLeft = [dataArrAll[0] objectForKey:@"items"];
    NSArray *dataArrRight = [[NSArray alloc] init];
    if (dataArrAll.count>1) {
        dataArrRight = [dataArrAll[1] objectForKey:@"items"];
    }
    
    
    NSMutableArray *contArrr = [NSMutableArray arrayWithCapacity:0];
    [contArrr addObjectsFromArray:dataArrLeft];
    [contArrr addObjectsFromArray:dataArrRight];
    
    
    NSArray *colorContent = contArrr;
    for (int i=0; i<colorContent.count; i++) {
        if (i<3) {
            
           // lb.text = content[i];
        }
        UILabel *colorLB = [self viewWithTag:i+1];
        colorLB.text = colorContent[i];
    }
}
-(void)setTitle:(NSString *)title
{
    UILabel *lb = [self viewWithTag:10];
    lb.text = title;
}
@end
