//
//  cp3.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "cp3.h"
#import "YYListWebVC.h"
@interface cp3 ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray * _investmerntArray;
}
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataArr;
@property (nonatomic, strong) UIButton *tagBt;
@property (nonatomic, assign) NSInteger btSeclctTag;
@end

@implementation cp3

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = ViewBackgroundColor;
    _btSeclctTag = 0;
    _investmerntArray = @[@"双色球",@"大乐透",@"福彩3D"];
    
    [self creadData];
    [self.view addSubview:self.tableView];
    [self headView];
    
   
}
-(void)creadData
{
    [self startRequests:self.navigationController.view];
    
    [requestClass newconsultingRequestImage:nil andOne:nil andTwo:nil andThree:nil andDitc:nil andDistinguish:6 success:^(BOOL state, NSDictionary *resultDict) {
        [self endRequests:self.navigationController.view];
        NSArray *arr1 = @[@"减法加号测蓝法",@"精准估算和值集合",@"精准选定6加1",@"篮球选号指标",@"利用空区判断号码",@"利用热号投注法",@"灵活利用蓝号杀手",@"排号组合有经验"];
        NSArray *arr2 = @[@"练号法投注五步骤",@"前区码跨度缩号",@"巧用和值分析法"];
        NSArray *arr3 = @[@"采用数字排序区中胆的方法",@"3D技巧-过滤缩水法",@"和值投注攻略"];
        [self.dataArr addObject:arr1];
        [_dataArr addObject:arr2];
        [_dataArr addObject:arr3];
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        [self endRequests:self.navigationController.view];
        NSArray *arr1 = @[@"减法加号测蓝法",@"精准估算和值集合",@"精准选定6加1",@"篮球选号指标",@"利用空区判断号码",@"利用热号投注法",@"灵活利用蓝号杀手",@"排号组合有经验"];
        NSArray *arr2 = @[@"练号法投注五步骤",@"前区码跨度缩号",@"巧用和值分析法"];
        NSArray *arr3 = @[@"采用数字排序区中胆的方法",@"3D技巧-过滤缩水法",@"和值投注攻略"];
        [self.dataArr addObject:arr1];
        [_dataArr addObject:arr2];
        [_dataArr addObject:arr3];
        [self.tableView reloadData];
    }];
    
    
    
    
}
-(void)headView
{
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, screenW, 40)];
    headView.backgroundColor = [UIColor whiteColor];
    for (int i=0; i<_investmerntArray.count; i++) {
        UIButton *bt = [[UIButton alloc] initWithFrame:CGRectMake(i*screenW/_investmerntArray.count, 0, screenW/_investmerntArray.count, 40)];
        [bt setTitle:_investmerntArray[i] forState:UIControlStateNormal];
        bt.titleLabel.font = [UIFont systemFontOfSize:14];
        [bt addTarget:self action:@selector(btsClick:) forControlEvents:UIControlEventTouchUpInside];
         bt.tag = i;
        [headView addSubview:bt];
       
        
        if (i==0) {
            [bt setTitleColor:sxyColor  forState:UIControlStateNormal];
            _tagBt =bt;
            bt.titleLabel.textColor = sxyColor;
        }else
        {
            [bt setTitleColor:UIColorFromRGB(0x111111)  forState:UIControlStateNormal];
        }
    }
    UIView *linebgView = [[UIView alloc] initWithFrame:CGRectMake(0, 38, screenW, 2)];
    linebgView.backgroundColor = ViewBackgroundColor;
    [headView addSubview:linebgView];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 38, screenW/_investmerntArray.count, 2)];
    lineView.backgroundColor = sxyColor;
    lineView.tag = 10;
    [headView addSubview:lineView];
    
    
    
    
    [self.view addSubview:headView];
}
-(void)btsClick:(UIButton *)bt
{
    _btSeclctTag = bt.tag;
    
    [_tagBt setTitleColor:UIColorFromRGB(0x111111)  forState:UIControlStateNormal];
    _tagBt = bt;
    bt.titleLabel.textColor = sxyColor;
    [bt setTitleColor:sxyColor  forState:UIControlStateNormal];
    
    UIView *lineView = [self.view viewWithTag:10];
    [UIView animateWithDuration:0.5 animations:^{
        lineView.frame = CGRectMake(bt.tag*screenW/_investmerntArray.count, 38, screenW/_investmerntArray.count, 2);
    }];
    [self.tableView reloadData];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *arr= _dataArr[_btSeclctTag];
    return arr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    NSArray *arr= _dataArr[_btSeclctTag];
    cell.textLabel.text = arr[indexPath.row];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YYListWebVC *web = [YYListWebVC new];
    web.title = _investmerntArray[_btSeclctTag];
    NSString *url = @"";
    switch (_btSeclctTag) {
        case 0:
        {
            url = [NSString stringWithFormat:@"ssq%ld",indexPath.row+1];
        }
            break;
        case 1:
        {
            url = [NSString stringWithFormat:@"dlt%ld",indexPath.row+1];
        }
            break;
        case 2:
        {
            url = [NSString stringWithFormat:@"fc3d%ld",indexPath.row+1];
        }
            break;
            
        default:
            break;
    }
    web.UrlStr = url;
    [self.navigationController pushViewController:web animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _dataArr;
}
-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 45, screenW, screenH-45)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _tableView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
