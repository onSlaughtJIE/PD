//
//  cp1.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "cp1.h"

@interface cp1 ()

@end

@implementation cp1

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
-(UIView *)buttonView
{
    UIView *buutonView = [[UIView alloc] initWithFrame:CGRectMake(0, 200, ScreemW, ScreemW)];
    
    for (int i=0; i<3; i++) {
        for (int y=0; y<3; y++) {
        }
    }
    
    return buutonView;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
