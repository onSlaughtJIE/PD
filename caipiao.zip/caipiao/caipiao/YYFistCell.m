//
//  YYFistCell.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYFistCell.h"
#define selectBjColor sxyColor
#define noSelectBjColor [UIColor whiteColor]
#define noSelectBjColorType [UIColor orangeColor]
#define noSelectTitleColor [UIColor blackColor]
@implementation YYFistCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andTypeType:(NSInteger)type andBTnummber:(NSInteger)btNummber
{
    if (self == [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUpWithType:type andbtNummber:btNummber];
        self.backgroundColor = ViewBackgroundColor;
        self.type = type;
    }
    return self;
}
-(void)setUpWithType:(NSInteger)type andbtNummber:(NSInteger)btNummber
{
    
    UIButton *titleButton = [[UIButton alloc] initWithFrame:CGRectMake(20, 20, 60, 30)];
    titleButton.titleLabel.font = [UIFont systemFontOfSize:14];
    titleButton.tag = 100;
    if (type ==0) {
        [titleButton setBackgroundImage:[UIImage imageNamed:@"LeftTitlee"] forState:UIControlStateNormal];;
        
    }else
    {
        [titleButton setBackgroundImage:[UIImage imageNamed:@"LeftTitleRed"] forState:UIControlStateNormal];;
    }
    [self addSubview:titleButton];
    
    
    UILabel *titleLb = [[UILabel alloc] initWithFrame:CGRectMake(100, 20, 100, 30)];
    titleLb.textColor = UIColorFromRGB(0x333333);
    titleLb.font = [UIFont systemFontOfSize:14];
    titleLb.tag = 101;
    [self addSubview:titleLb];
    
    
    for (int i=0; i<btNummber; i++) {
        CGFloat btWith = (ScreemW-20*8)/7;
        
        UIButton *bt = [[UIButton alloc] initWithFrame:CGRectMake(20+(btWith+20)*(i%7),20+ (btWith+10)*(i/7)+40, btWith, btWith)];
        [bt setTitle:[NSString stringWithFormat:@"%d",i+1] forState:UIControlStateNormal];
        [bt setBackgroundColor:[UIColor whiteColor]];
        [bt.layer setCornerRadius:btWith/2];
        [bt setTitleColor:UIColorFromRGB(0x333333) forState:UIControlStateNormal];
        bt.tag = i+1;
        [bt addTarget:self action:@selector(btClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:bt];
        
    }
    
    
}

-(void)setDataArr:(NSMutableArray *)dataArr
{
    for (int i=1; i<dataArr.count+1; i++) {
        UIButton *bt = [self  viewWithTag:i];
        NSMutableDictionary *dataDic = dataArr[i-1];
        NSString *btTag =dataDic[@"btTag"];
        if ([btTag isEqualToString:@"1"]) {
            if (_type ==0) {
                [bt setBackgroundColor:[UIColor blueColor]];
                [bt setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }else
            {
                [bt setBackgroundColor:sxyColor];
                [bt setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            }
            
            
        }else
        {
            [bt setBackgroundColor:[UIColor whiteColor]];
            [bt setTitleColor:UIColorFromRGB(0x333333) forState:UIControlStateNormal];
        }
    }
}
-(void)setLeftTitle:(NSString *)leftTitle
{
    UIButton *titleBt= [self viewWithTag:100];
    [titleBt setTitle:leftTitle forState:UIControlStateNormal];
}
-(void)setTitle:(NSString *)title
{
    
    
    UILabel *titleLb = [self viewWithTag:101];
    titleLb.text = title;
}
-(void)btClick:(UIButton *)bt
{
    [self.delegate buttonClickWithSelectId:bt.tag andCell:self];
}

@end
