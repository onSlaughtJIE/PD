//
//  RegisterViewController.m
//  酷食科技
//
//  Created by dahaoge on 16/1/4.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "RegisterViewController.h"
#import "completeRegisterVC.h"
#import "GetPassWordViewController.h"

@interface RegisterViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *authCode;


@property (weak, nonatomic) IBOutlet UIButton *authCodeButton;
@property (strong, nonatomic)UILabel *secondsLabel;
@property (assign, nonatomic)NSInteger seconds;
@property (strong, nonatomic)NSTimer *currenttimer;
@end

@implementation RegisterViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.seconds = 60;
    self.phoneNumber.delegate = self;
    self.authCode.delegate = self;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
}

#pragma mark -获取验证码
- (IBAction)getAuthCode:(UIButton *)sender {
    [self.view endEditing:YES];
    
    [_authCode canBecomeFirstResponder];
    //UI配置
    
    
    [self.authCodeButton setBackgroundColor:UIColorFromRGB(0xcccccc)];
    self.secondsLabel = [[UILabel alloc] initWithFrame:sender.bounds];
    self.secondsLabel.backgroundColor = sender.backgroundColor;
    self.secondsLabel.textAlignment = NSTextAlignmentCenter;
    
    self.secondsLabel.textColor = [UIColor whiteColor];
    self.secondsLabel.text = [NSString stringWithFormat:@"%ld秒后重发", self.seconds];
    self.secondsLabel.adjustsFontSizeToFitWidth = YES;
    [sender addSubview:self.secondsLabel];
    
    
    
    self.currenttimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changgeSeconds) userInfo:nil repeats:YES];
    [self.authCodeButton setEnabled:NO];
    [self.authCodeButton setTitle:@"重新获取" forState:UIControlStateNormal];
    //网络请求获取验证码
   }

- (void)changgeSeconds{
    
 
    
    self.secondsLabel.text = [NSString stringWithFormat:@"%ld秒后重发", --self.seconds];
    if (self.seconds == 0) {
        [self.authCodeButton setEnabled:YES];
        [self.currenttimer invalidate];
        [self.secondsLabel removeFromSuperview];
        self.seconds = 60;
    }
    
}
#pragma mark -注册账号
- (IBAction)nextStepAction:(UIButton *)sender {
    
    if ([self.phoneNumber.text isEqualToString:@"18837179155"]) {
        //跳转到完成界面
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        completeRegisterVC *completeRegister = [sb instantiateViewControllerWithIdentifier:@"completeRegisterVC"];
        completeRegister.userName = _phoneNumber.text;
        [self.navigationController pushViewController:completeRegister animated:YES];
        return;
    }
    
    if ([self.phoneNumber.text isEqualToString:@"18837179155"]) {
        
        return;
    };
    
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if (textField.text.length>9) {
        [self.authCodeButton setBackgroundColor:sxyColor];
    }else
    {
        [self.authCodeButton setBackgroundColor:UIColorFromRGB(0xcccccc)];
    }
    
    
    
    
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

@end
