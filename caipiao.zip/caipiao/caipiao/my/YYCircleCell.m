//
//  YYCircleCell.m
//  纳食
//
//  Created by apple on 2017/4/22.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYCircleCell.h"
@interface YYCircleCell()
@property (weak, nonatomic) IBOutlet UILabel *titleLB;
@property (weak, nonatomic) IBOutlet UILabel *contentLB;

@end
@implementation YYCircleCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}
-(void)setDataDic:(NSMutableDictionary *)dataDic
{
    ;
    _titleLB.text = [dataDic objectForKey:@"title"];
    _contentLB.text = [NSString stringWithFormat:@"%@    来自:%@",[Helper TransformTimeDateTOYead:[dataDic objectForKey:@"time"]],[dataDic objectForKey:@"source"]];
}
@end
