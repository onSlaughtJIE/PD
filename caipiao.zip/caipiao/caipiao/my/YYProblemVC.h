//
//  YYProblemVC.h
//  纳食
//
//  Created by apple on 2017/4/22.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYProblemVC : UIViewController

@end
