//
//  requestClass.h
//  酷食科技
//
//  Created by 酷食科技 on 16/4/25.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface requestClass : NSObject

/*******     群聊请求     *******/
+(void)groupChatRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;
/*******     行业圈请求     *******/
+(void)industryRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******     带图请求     *******/
+(void)requestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******     无图请求     *******/
+(void)requestStartWithCallOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *responseObject))compeletion failure:(void(^)(NSError *error))failure;
/*******     通讯录请求     *******/
+(void)addressBookRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;
/*******     登入注册请求     *******/
+(void)loginRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;
/*******     咨询请求请求     *******/
+(void)consultingRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSMutableDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

+(void)newconsultingRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSMutableDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******     认证上传数据     *******/
+(void)CertityUPRequestImage:(NSMutableArray *)imageArr andUrl:(NSString *)UrlStr uid:(int)Uid DataDic:(NSMutableDictionary *)UpDic success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******     请求认证信息    *******/ // 1--4个人  厂家  经销商  超市  服务商
+(void)GetCertityInforMationWIthSign:(int)Sign  Success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******    收藏   取消收藏     *******/
+(void)CollectionviewArticleID:(NSString *)ArticleID andUrl:(NSString *)UrlStr success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;


/*******    得到店铺信息    *******/
+(void)GetStoreInformationWIthStoreID:(NSString *)StoreID success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******    创建   修改店铺信息    *******/   //创建 不传storeid           修改  传storeid
+(void)CreatStroeInformationWith:(UIImage *)StroreImage StroreID:(NSString *)StroeID Dictionary:(NSDictionary *)ParameterDic success:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******     得到产品列表     进入自己的店铺不需要shipid   进入别人的店铺需要shipid*******/
+(void)GetProductListWith:(NSMutableDictionary *)Dic successx:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******     得到产品详情    *******/
+(void)GetProductInformationWithProductId:(NSString *)productID  ShopId:(NSString *)ShopId success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure;

/*******     发布   修改产品    *******/
+(void)IssueNewProduct;

/*******     获取单个/所有产品评论    *******/
+(void)GetProductTalkWIth:(NSDictionary *)ParameterDic success:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;

/*******   收藏/取消收藏店铺    *******/
+(void)IfCollectStoreWithUrl:(NSString *)UrlStr ShopId:(int)ShopId success:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;
/*******   客户留言   *******/
+(void)GetCustomerLeaveMessageWithShopId:(int)ShopId Page:(int)page  success:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure;
/*******   判断认证状态   ******/
+(void)JudgeCertifyStatesuccess:(void(^)(int result))Complete;
/*******   招商专场 糖酒会列表  ******/
+(void)FindSugarGetInforListWithDic:(NSMutableDictionary *)UpDic success:(void(^)(BOOL state,NSDictionary *resultDict))compleletion failure:(void(^)(NSError *error))failure;

/*******   招商专场 糖酒会 展会详情  ******/
+(void)FindSugarGetDetailInforMationWIth:(NSDictionary *)Updic success:(void(^)(BOOL state,NSDictionary *resultDict))Completion failure:(void(^)(NSError *error))failure;


/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
/*******     请求     *******/
@end
