//
//  YYLoanVC.h
//  酷食科技
//
//  Created by 酷食科技 on 17/3/30.
//  Copyright © 2017年 dahaoge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYLoanVC : UIViewController

@end
