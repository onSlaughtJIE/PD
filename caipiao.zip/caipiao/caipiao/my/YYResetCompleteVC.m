//
//  YYResetCompleteVC.m
//  酷食科技
//
//  Created by 酷食科技 on 16/12/28.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "YYResetCompleteVC.h"
#import "LoginViewController.h"
@interface YYResetCompleteVC ()
@property (weak, nonatomic) IBOutlet UIButton *completeBT;

@end

@implementation YYResetCompleteVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"重置密码";
    self.view.backgroundColor = [UIColor whiteColor];
    [_completeBT.layer setCornerRadius:5];
   
}
- (IBAction)buutonClick:(id)sender {
    NSArray *temArray = self.navigationController.viewControllers;
    for(UIViewController *temVC in temArray)
        
    {
        if ([temVC isKindOfClass:[LoginViewController class]])
            
        {
            [self.navigationController popToViewController:temVC animated:YES];
            
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
