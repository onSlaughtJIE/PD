//dwd
//  LoginViewController.m
//  酷食科技
//
//  Created by dahaoge on 15/12/31.
//  Copyright © 2015年 dahaoge. All rights reserved.
//


#import "LoginViewController.h"


#import "RegisterViewController.h"


@interface LoginViewController ()
//账号
@property (weak, nonatomic) IBOutlet UITextField *nameId;
//密码
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UIButton *weixinLoginBT;
@property (weak, nonatomic) IBOutlet UIView *weixinLineView;

@property (weak, nonatomic) IBOutlet UILabel *weixinContentLB;
@property(nonatomic, strong)UIImageView *contentLineImageView;
@property(nonatomic, strong)NSString *name;
@property(nonatomic, strong)NSString *pwd;
@property(nonatomic, assign)NSInteger loginTag;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    NSString *userPhone = [userDefault objectForKey:@"userPhone"];
    if (userPhone.length>0) {
        _nameId.text = userPhone;
    }
    _loginTag = 0;
    
    [_weixinLoginBT.layer setBorderColor:sxyColor.CGColor];
    [_weixinLoginBT.layer setBorderWidth:1];
    
    self.nameId.delegate = self;
    self.password.delegate = self;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:19],NSForegroundColorAttributeName:GrayTitleColor}];
    
    //把返回按钮隐藏方法
    if([_isReturn isEqualToString:@"1"]){
        UIButton *button=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
        button.titleLabel.text=@"";
        self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:button];
    }
    [[NSNotificationCenter
      defaultCenter] addObserver: self selector: @selector(wechatDidLoginNotification:) name: @"wechatDidLoginNotification" object: nil];
}
-(void)viewWillAppear:(BOOL)animated
{
    
}
- (IBAction)registClick:(id)sender {
    [userDefault setObject:@"1" forKey:@"logintype"];
}
- (IBAction)getPwd:(id)sender {
    [userDefault setObject:@"2" forKey:@"logintype"];
}
-(void)wechatDidLoginNotification:(NSNotification*)aNotification
{
    
    
    
    
}




+ (void)initialize{
}

#pragma mark -UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark -触摸空白让键盘消失
//触摸的方法是在UIRespond里面的
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    if ([self.nameId resignFirstResponder] == YES) {
        return;
    }else{
        [self.nameId resignFirstResponder];
    }
    if ([self.password resignFirstResponder] == YES) {
        return;
    }else{
        [self.password resignFirstResponder];
    }
    
}



#pragma mark -navigationitem返回
- (IBAction)didSelectLeftAction:(id)sender {
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"username"];
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"token"];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -第三方登录




+ (AFHTTPSessionManager *)uploadImageWithUrl:(NSString *)url
                                       image:(UIImage *)image
                                  completion:(NSString *)completion
                                  errorBlock:(NSString *)errorBlock {
    
    UIImage *images = [UIImage imageNamed:@"LaunchImage"];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager POST:[NSString stringWithFormat:@"%@/Ucenter/app/updateUserInfo.html?uid=3",RequestDuanKou] parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        NSData *imageData = UIImageJPEGRepresentation(images, 1);
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyyMMddHHmmss";
        NSString *str = [formatter stringFromDate:[NSDate date]];
        NSString *fileName = [NSString stringWithFormat:@"%@.jpg", str];
        // 上传图片，以文件流的格式
        [formData appendPartWithFileData:imageData name:@"myfiles" fileName:fileName mimeType:@"image/jpeg"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
    return manager;
}
#pragma mark -login
-(void)login
{
    
}
-(void)loginComplete
{
    
    
}
- (IBAction)loginAction:(UIButton *)sender {
    
    if (self.nameId.text.length != 0 && self.password.text.length != 0) {
        
        //登录, 验证账号和密码
        [self startRequests:self.view andContent:@"正在登录"];
        [requestClass requestStartWithCallOne:self.nameId.text andTwo:self.password.text andThree:nil andDitc:nil andDistinguish:1 success:^(BOOL state, NSDictionary *responseObject) {
            [self endRequests:self.view];
            [self.navigationController popViewControllerAnimated:YES];
            [userDefault setObject:_nameId.text forKey:@"name"];
            [self showHint:@"登录成功"];
            
        } failure:^(NSError *error) {
            [self endRequests:self.view];
            
            [self showHint:error.localizedDescription];
        }];
        [self.nameId resignFirstResponder];
        [self.password resignFirstResponder];
    }else{
        
        [self alertActionWith:@"提示" content:@"账号和密码不能为空" alertStyle:UIAlertControllerStyleAlert isSure:YES];
        
    }
}

@end
