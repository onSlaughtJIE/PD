//
//  YYCircleVC.m
//  纳食
//
//  Created by apple on 2017/4/22.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYCircleVC.h"
#import "YYCircleCell.h"
#import "YYListWebVC.h"
@interface YYCircleVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)UITableView *tableView;
@end

@implementation YYCircleVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.backgroundColor = ViewBackgroundColor;
    [self.view addSubview:self.tableView];
    self.title = @"彩坛资讯";
    [self reloadData];
}
-(void)reloadData
{
    NSData *JSONData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"zixun" ofType:@"json"]];
    
    NSMutableDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingAllowFragments error:nil];
    [self startRequests:self.navigationController.view];
    [requestClass newconsultingRequestImage:nil andOne:nil andTwo:nil andThree:nil andDitc:nil andDistinguish:5 success:^(BOOL state, NSDictionary *resultDict) {
        [self endRequests:self.navigationController.view];
        self.dataArr = dataDic[@"data"][@"newslist"];
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        [self endRequests:self.navigationController.view];
        [self showHint:@"网络连接失败!!!"];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return self.dataArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    YYCircleCell  *cell = [tableView dequeueReusableCellWithIdentifier:@"YYCircleCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"YYCircleCell" owner:nil options:nil] lastObject];
    }
    
    cell.dataDic = self.dataArr[indexPath.row];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dataDic = self.dataArr[indexPath.row];
    YYListWebVC *web = [YYListWebVC new];
    web.type = 1;
    web.UrlStr = [NSString stringWithFormat:@"http://www.caipiao688.com/newsone.html?love=688&newsid=%@&rt=1004844897",[dataDic objectForKey:@"id"]];
    [self.navigationController pushViewController:web animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH-50)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _tableView;
}
-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr = [NSMutableArray arrayWithCapacity:0];
    }
    return  _dataArr;
}
@end
