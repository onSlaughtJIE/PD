//
//  requestClass.m
//  酷食科技
//
//  Created by 酷食科技 on 16/4/25.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

/**     无图方法
 登入请求        ----------->     ID = 1
 登入请求        ----------->     ID = 1
 登入请求        ----------->     ID = 1
 登入请求        ----------->     ID = 1
 登入请求        ----------->     ID = 1
 */

#import "requestClass.h"
#import "Helper.h"
#import "LoginViewController.h"

@implementation requestClass
+(void)newconsultingRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSMutableDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    AFHTTPSessionManager *manager = [Helper helperForManager];
    switch (distinguish) {
        case 1:
        {
            // 创建同步链接
            NSString  *urlString = [@"http://www.caipiao688.com/v1/opens?love=688"  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 2:
        {
            // 创建同步链接
            NSString  *urlString = [@"ttp://www.caipiao688.com/v1/news?love=688&lotterykey=shuangseqiu&type=yuce&version=4.5"  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 3:
        {
            // 创建同步链接
            NSString  *urlString = [@"http://www.caipiao688.com/v1/opens?love=688"  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 4:
        {
            // 创建同步链接
            NSString  *urlString = [@"http://www.caipiao688.com/hometips?love=688&appflag=cp688&platform=ios&version=4.5"  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 5:
        {
            // 创建同步链接
            
            [manager GET:@"http://api-php.nashigroup.com/news/AppHome/check1.html" parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 6:
        {
            // 创建同步链接
            
            [manager GET:@"http://api-php.nashigroup.com//news/appfind/infoDetail.html" parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        default:
            break;
    }
}
#pragma mark   >--------------------<  **  咨询请求 **  >------------------------------>>
+(void)consultingRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSMutableDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    if(([self requestNetworkJudgment] == -1))
    {
        NSError *error = [[NSError alloc] init];
        failure(error);
    }else
    {
        NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
        
        AFHTTPSessionManager *manager = [Helper helperForManager];
        switch (distinguish)
        {
            case 1:
            {
#pragma mark   ----------------------------------------------------对新闻评论
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterTWO forKey:@"newsid"];
                [dic setObject:parameterOne forKey:@"content"];
                
                [manager POST:[NSString stringWithFormat:@"%@/news/app/addComment.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"data"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
                
            }
                break;
            case 2:
            {
#pragma mark   ----------------------------------------------------对新闻评论
                NSString *aa = [NSString stringWithFormat:@"%@/news/appHome/detail/id/%@.html?", RequestDuanKou, parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 3:
            {
#pragma mark   ----------------------------------------------------新闻详情评论
                NSString *aa = [NSString stringWithFormat:@"%@/news/appHome/getcommentList.html?app=news&mod=index&newsid=%@&page=1&count=200&order=1",RequestDuanKou,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 4:
            {
#pragma mark   ----------------------------------------------------搜索请求
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"keywords"];
                
                [manager POST:[NSString stringWithFormat:@"%@/news/AppHome/newslist.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
                
                
                
                //                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/newslist/keywords/%@.html",DuanKou,parameterOne];
                //
                //                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                //
                //                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                //                    compeletion(YES,responseObject);
                //
                //                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                //                    failure(error);
                //                }];
            }
                break;
            case 5:
            {
#pragma mark   ----------------------------------------------------新闻详情点赞
                NSString *aa = [NSString stringWithFormat:@"%@/news/app/newsCommentSupport.html?appname=News&targetUid=%@&id=%@&newsid=%@&commentpage=%@&commentrow=%@&token=%@",RequestDuanKou,[contentDit objectForKey:@"targetUid"],[contentDit objectForKey:@"id"],[contentDit objectForKey:@"newsid"],[contentDit objectForKey:@"commentpage"],[contentDit objectForKey:@"commentrow"],token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 6:
            {
#pragma mark   ----------------------------------------------------咨询消息通知
                NSString *aa = [NSString stringWithFormat:@"%@/news/app/getNewsMsgList.html?token=%@",RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 7:
            {
#pragma mark   ----------------------------------------------------加载咨询消息通知数
                NSString *aa = [NSString stringWithFormat:@"%@/news/app/noReadMsgCount.html?token=%@",RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 8:
            {
#pragma mark   ----------------------------------------------------清空咨询所有未读消息
                NSString *aa = [NSString stringWithFormat:@"%@/news/app/setNewsNoReadMsgReaded.html?token=%@",RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 9:
            {
#pragma mark   ----------------------------------------------------新闻详情评论
                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/getcommentList.html?app=news&mod=index&newsid=%@&page=1&count=200&order=1&token=%@",RequestDuanKou,parameterOne,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 10:
            {
#pragma mark   ----------------------------------------------------朋友圈消息通知
                NSString *aa = [NSString stringWithFormat:@"%@/weibo/app/getWeiboMsgList.html?token=%@",RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 11:
            {
#pragma mark   ----------------------------------------------------清空朋友圈未读消息数
                NSString *aa = [NSString stringWithFormat:@"%@/weibo/app/setWeiboNoReadMsgReaded.html?token=%@",RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 12:
            {
#pragma mark   ----------------------------------------------------清空朋友圈未读消息
                NSString *aa = [NSString stringWithFormat:@"%@/weibo/app/WeiboMsgDelAll.html?token=%@",RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 13:
            {
#pragma mark   ----------------------------------------------------幻灯片咨询浏览数增加接口
                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/detailimg/id/%@.html",RequestDuanKou,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 14:
            {
#pragma mark   ----------------------------------------------------幻灯片咨询浏览数增加接口
                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/commentNewsSum/id/%@.html",RequestDuanKou,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 15:
            {
#pragma mark   ----------------------------------------------------视屏直播详情接口
                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/detail.html?id=%@",RequestDuanKou,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            default:
                break;
        }
    }
    
}

#pragma mark   >--------------------<  **  登入注册请求 **  >------------------------------>>
+(void)loginRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    if(([self requestNetworkJudgment] == -1))
    {
        NSError *error = [[NSError alloc] init];
        failure(error);
    }else
    {
        
        NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
        AFHTTPSessionManager *manager = [Helper helperForManager];
        switch (distinguish) {
            case 1:
            {
#pragma mark   ----------------------------------------------------找回密码
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/miMobile.html?account=%@&newpassword=%@", RequestDuanKou, parameterOne,  parameterTWO];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 2:
            {
#pragma mark   ----------------------------------------------------注册账号
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/register.html?username=%@&password=%@&client=ios", RequestDuanKou,parameterOne, parameterTWO];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 3:
            {
#pragma mark   ----------------------------------------------------获取验证码 注册账号
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/sendverify.html?account=%@&type=mobile", RequestDuanKou, parameterOne];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 4:
            {
#pragma mark   ----------------------------------------------------获取验证码 找回密码
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/sendverifyfindpsw.html?account=%@&type=mobile", RequestDuanKou, parameterOne];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 5:
            {
#pragma mark   ----------------------------------------------------所有用户数据缓存
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/myfriendlist.html?token=%@", RequestDuanKou, token];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 6:
            {
#pragma mark   ----------------------------------------------------判断版本号http://api-php.nashigroup.com/news/AppHome/check1.html
                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/check1.html", RequestDuanKou];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 7:
            {
#pragma mark   ----------------------------------------------------添加好友请求
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"invitecode"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appinvite/index.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
            }
                break;
            case 8:
            {
#pragma mark   ----------------------------------------------------添加好友请求
                
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"code"];
                [dic setObject:@"ios" forKey:@"client"];
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appuser/weixinLogin.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            case 9:
            {
#pragma mark   ----------------------------------------------------判断手机号
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"mobile"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appuser/isBindMobile.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            case 10:
            {
#pragma mark   ----------------------------------------------------验证验证码
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"mobile"];
                [dic setObject:parameterTWO forKey:@"verify"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appuser/istrueVerify.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            case 11:
            {
#pragma mark   ----------------------------------------------------验证验证码
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"mobile"];
                [manager POST:[NSString stringWithFormat:@"%@ucenter/appuser/sendVerify.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            case 12:
            {
#pragma mark   ----------------------------------------------------验证验证码
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:[userDefault objectForKey:@"uid"] forKey:@"uid"];
                [dic setObject:parameterOne forKey:@"pass"];
                [dic setObject:parameterTWO forKey:@"mobile"];
                [dic setObject:parameterThree forKey:@"verify"];
                [dic setObject:@"ios" forKey:@"client"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appuser/setPassword.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            case 13:
            {
#pragma mark   ----------------------------------------------------验证验证码
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"mobile"];
                [dic setObject:parameterTWO forKey:@"verify"];
                [dic setObject:@"2" forKey:@"type"];
                 [dic setObject:@"ios" forKey:@"client"];
                [dic setObject:[userDefault objectForKey:@"uid"] forKey:@"uid"];
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appuser/bindMobile.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            case 14:
            {
#pragma mark   ----------------------------------------------------验证密码正确性
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"mobile"];
                [dic setObject:parameterTWO forKey:@"verify"];
                [dic setObject:parameterThree forKey:@"pass"];
                [dic setObject:@"1" forKey:@"type"];
                
                [dic setObject:[userDefault objectForKey:@"uid"] forKey:@"uid"];
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appuser/bindMobile.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                    failure(error);
                }];
            }
                break;
            default:
                break;
        }
    }
}

#pragma mark   >--------------------<  **  通讯录请求 **  >------------------------------>>
+(void)addressBookRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    if(([self requestNetworkJudgment] == -1))
    {
        NSError *error = [[NSError alloc] init];
        failure(error);
    }else
    {
        
        NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
        AFHTTPSessionManager *manager = [Helper helperForManager];
        switch (distinguish) {
            case 1:
            {
#pragma mark   ----------------------------------------------------查找人/群请求
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"keywords"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/app/souUserlist.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 2:
            {
#pragma mark   ----------------------------------------------------添加好友请求
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"fid"];
                [dic setObject:parameterTWO forKey:@"note"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/app/friendAdd.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
            }
                break;
            case 3:
            {
#pragma mark   ----------------------------------------------------好友标签分类请求
                
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getfriendTagGroupList.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 4:
            {
#pragma mark   ----------------------------------------------------创建标签请求
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"fids"];
                [dic setObject:parameterTWO forKey:@"title"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/app/addfriendTagGroup.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 5:
            {
#pragma mark   ----------------------------------------------------黑名单名单请求
                
                
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getUserBlackList.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 6:
            {
#pragma mark   ----------------------------------------------------加入/移除黑名单
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/%@.html?token=%@&fid=%@", RequestDuanKou,parameterOne,token,parameterTWO];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 7:
            {
#pragma mark   ----------------------------------------------------删除好友
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/friendDel.html?token=%@&fid=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 8:
            {
#pragma mark   ----------------------------------------------------群分类下群信息请求
                
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/qunlist.html?token=%@&typeid=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 9:
            {
#pragma mark   ----------------------------------------------------获取好友请求列表
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getfriendRequestList.html?token=%@&page=%@&pagesize=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 10:
            {
                
#pragma mark   ----------------------------------------------------处理好友申请
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/dealfriendRequest.html?token=%@&action=%@&id=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 11:
            {
#pragma mark   ----------------------------------------------------获取指定用户指定好友的所在分组信息
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getGroupStatus.html?token=%@&fid=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 12:
            {
#pragma mark   ----------------------------------------------------保存标签
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"oldtitles"];
                [dic setObject:parameterTWO forKey:@"titles"];
                [dic setObject:parameterThree forKey:@"fid"];
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/app/addfriendTagGroups.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 13:
            {
#pragma mark   ----------------------------------------------------获取标签成员信息
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getfriendTagGroupUserListByID.html?token=%@&gid=%@", RequestDuanKou,token,[contentDit objectForKey:@"follow_group_id"]];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 14:
            {
#pragma mark   ----------------------------------------------------创建标签请求
                
                NSMutableDictionary *dics = [[NSMutableDictionary alloc] init];
                [dics setObject:parameterOne forKey:@"fids"];
                [dics setObject:parameterTWO forKey:@"title"];
                [dics setObject:parameterThree forKey:@"gid"];
                
                
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/app/editfriendTagGroup.html?token=%@",RequestDuanKou,token] parameters:dics constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 15:
            {
#pragma mark   ----------------------------------------------------删除标签请求
                
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/deletefriendTagGroup.html?token=%@&gid=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 16:
            {
#pragma mark   ----------------------------------------------------添加群请求
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"qunid"];
                [dic setObject:parameterTWO forKey:@"note"];
                
                [manager POST:[NSString stringWithFormat:@"%@/group/app/selfaddqun.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
            }
                break;
            case 17:
            {
#pragma mark   ----------------------------------------------------消息数
                
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getmsgoverview.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 18:
            {
#pragma mark   ----------------------------------------------------群通知消息列表
                
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/getgroupRequestList.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 19:
            {
                
#pragma mark   ----------------------------------------------------处理通知申请
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/dealgroupRequest.html?token=%@&action=%@&msgid=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 20:
            {
                
#pragma mark   ----------------------------------------------------得到推荐陌生人
                
                NSString *aa;
                if(parameterTWO==nil){//庆龙
                    aa= [NSString stringWithFormat:@"%@/Ucenter/app/getUserInfo.html?token=%@&action=%@&target=%@", RequestDuanKou,token,@"2",parameterOne];
                }else{
                    aa= [NSString stringWithFormat:@"%@/Ucenter/app/getUserInfo.html?token=%@&action=%@&target=%@", RequestDuanKou,token,parameterTWO,parameterOne];
                }
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 21:
            {
                
#pragma mark   ----------------------------------------------------咨询请求
                NSString *aa = [NSString stringWithFormat:@"%@/news/appHome/newslist/category/%ld.html?category=%@&page=%@", RequestDuanKou, (NSInteger)1,parameterOne,parameterTWO];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 22:
            {
#pragma mark   ----------------------------------------------------获取标签成员信息
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getfriendTagGroupUserListByID.html?token=%@&gid=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 23:
            {
#pragma mark   ----------------------------------------------------获取标签成员信息
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterOne forKey:@"fid"];
                [dic setObject:parameterTWO forKey:@"alias"];
                
                
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/app/setfriendremark.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
                
                
                
            }
                break;
            case 24:
            {
#pragma mark   ----------------------------------------------------
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/grouptypes.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 25:
            {
                
#pragma mark   ----------------------------------------------------咨询请求
                NSString *aa = [NSString stringWithFormat:@"%@/news/appHome/downRefresh.html?newsid=%@&category=%@", RequestDuanKou, parameterThree,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 26:
            {
                
#pragma mark   ----------------------------------------------------咨询请求
                NSString *aa = [NSString stringWithFormat:@"%@/news/appHome/upperRefresh.html?newsid=%@&category=%@", RequestDuanKou, parameterThree,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            default:
                break;
        }
    }
}
#pragma mark   >--------------------<  **  群聊请求 **  >------------------------------>>
+(void)groupChatRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    if(([self requestNetworkJudgment] == -1))
    {
        NSError *error = [[NSError alloc] init];
        failure(error);
    }else
    {
        
        NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
        NSString *uid =[[NSUserDefaults standardUserDefaults] objectForKey:@"uid"];
        AFHTTPSessionManager *manager = [Helper helperForManager];
        switch (distinguish) {
            case 1:
            {
#pragma mark   ----------------------------------------------------个人好友分类标签
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/mytaglist.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
                
            }
                break;
            case 2:
            {
                
#pragma mark   ----------------------------------------------------个人好友列表请求    */
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/friendlistbyuid.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 3:
            {
#pragma mark   ----------------------------------------------------个人好友分类标签     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/myfriendlist.html?token=%@&tag=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 4:
            {
#pragma mark   ----------------------------------------------------群分类    */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/grouptypes.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 5:
            {
#pragma mark   ----------------------------------------------------个人好友分类标签     */
                [manager POST:[NSString stringWithFormat:@"%@/group/app/create.html?token=%@",RequestDuanKou,token] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
            }
                break;
            case 6:
            {
#pragma mark   ----------------------------------------------------我加入/管理/推荐群组     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/myqun.html?token=%@&action=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 7:
            {
#pragma mark   ----------------------------------------------------获取陌生群     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/getGroupInfoById.html?token=%@&qunid=%@", RequestDuanKou,token,parameterOne];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    NSLog(@"%@",responseObject[@"message"]);
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 8:
            {
#pragma mark   ----------------------------------------------------群添加成员     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/jiaqun.html?token=%@&qunid=%@&uids=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 9:
            {
#pragma mark   ----------------------------------------------------群减少成员     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/delfromqun.html?token=%@&qunid=%@&uids=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 10:
            {
#pragma mark   ----------------------------------------------------群举报原因     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/jubaolist.html?token=%@", RequestDuanKou,token];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 11://61a97bda719c9d1b95ff49960295c2d4
            {
#pragma mark   ----------------------------------------------------群举报原因     */
                
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/addReport.html?token=%@",RequestDuanKou,token];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterOne forKey:@"qunid"];
                [dic setObject:parameterTWO forKey:@"reason"];
                [dic setObject:parameterThree forKey:@"action"];
                
                [manager POST:aa parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    
                }];
                
            }
                break;
            case 12:
            {
#pragma mark   ----------------------------------------------------退出群   解散群     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/%@.html?token=%@&qunid=%@", RequestDuanKou,parameterOne,token,parameterTWO];
                
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 13:
            {
#pragma mark   ----------------------------------------------------退出群   解散群     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/transferGroup.html?token=%@&qunid=%@&uid=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 14:
            {
#pragma mark   ----------------------------------------------------设置群公告     */
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"qunid"];
                [dic setObject:parameterTWO forKey:@"gonggao"];
                
                [manager POST:[NSString stringWithFormat:@"%@/group/app/addGongGao.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    NSLog(@"11");
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    NSLog(@"22");
                    NSLog(@"%@",[responseObject objectForKey:@"message"]);
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 15:
            {
#pragma mark   ----------------------------------------------------群设置  设置裙类别/
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterOne forKey:@"qunid"];
                [dic setObject:parameterThree forKey:@"istopchat"];
                
                [manager POST:[NSString stringWithFormat:@"%@/group/app/setGroupinfo.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 16:
            {
#pragma mark ----------------------------------------------------移除本群     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/delfromqun.html?token=%@&qunid=%@&uids=%@",RequestDuanKou,token,parameterOne,parameterTWO];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 17:
            {
#pragma mark   ----------------------------------------------------移除本群     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/setGroupMemberPostion.html?token=%@&qunid=%@&uid=%@&targetlevel=%@",RequestDuanKou,token,parameterOne,parameterTWO,parameterThree];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 18:
            {
#pragma mark   ----------------------------------------------------群成员禁言     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/modifyGroupMemberBan?token=%@&qunid=%@&uid=%@&action=%@&minute=%@",RequestDuanKou,token,parameterOne,parameterTWO,parameterThree,imageArr[0]];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 19:
            {
#pragma mark   ----------------------------------------------------判断当前用户是否在群里被禁言     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/getGroupMemberBanInfo.html?qunid=%@&uid=%@&token=%@",RequestDuanKou,parameterOne,uid,token];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 20:
            {
#pragma mark   ----------------------------------------------------判断当前用户是否在群里被禁言     */
                NSString *aa = [NSString stringWithFormat:@"%@/group/app/getGroupInfoByHXId.html?hxid=%@&token=%@",RequestDuanKou,parameterOne,token];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 21:
            {
#pragma mark   ----------------------------------------------------判断当前用户是否在群里被禁言     */
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/getrandtop6userlist.html?token=%@",RequestDuanKou,token];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 22:
            {
#pragma mark   ----------------------------------------------------一个行业圈的相关群组     */
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/relatequn.html",RequestDuanKou];
                [dic setValue:token forKey:@"token"];
                [dic setValue:parameterOne forKey:@"title"];
                [manager POST:aa parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    
                }];
            }
                break;
            case 23:
            {
#pragma mark   ----------------------------------------------------获取所有群成员    */
                NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/relatedforumlist.html?token=%@&typeid=%@",RequestDuanKou,token,parameterOne];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 24:
            {
#pragma mark   ----------------------------------------------------获取所有群成员    */
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/readMessage.html?token=%@&message_id=%@",RequestDuanKou,token,parameterOne];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 25:
            {
#pragma mark   ----------------------------------------------------获取所有群成员    */
                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/commentNewsSum/id/1.html?token=%@&message_id=%@",RequestDuanKou,token,parameterOne];
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 26:
            {
#pragma mark   ----------------------------------------------------获取所有群成员    */
                
                NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/addReport.html?token=%@",RequestDuanKou,token];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterOne forKey:@"postid"];
                [dic setObject:parameterTWO forKey:@"reason"];
                
                [manager POST:aa parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    
                }];
                
                
            }
                break;
            case 27:
            {
#pragma mark   ----------------------------------------------------群设置  设置裙类别/
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                [dic setObject:parameterOne forKey:@"qunid"];
                [dic setObject:parameterThree forKey:parameterTWO];
                [manager POST:[NSString stringWithFormat:@"%@/group/app/setGroupinfo.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 28:
            {
#pragma mark   ----------------------------------------------------群设置  设置裙类别/
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/isFriend.html?token=%@&target=%@",RequestDuanKou,token,parameterOne];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 29:
            {
#pragma mark   ----------------------------------------------------判断是不是好友    */
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterOne forKey:@"hxid"];
                [dic setObject:parameterThree forKey:@"istopchat"];
                
                [manager POST:[NSString stringWithFormat:@"%@/group/app/setGrouptopinfo.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
                
            }
                break;
            case 30:
            {
#pragma mark   ----------------------------------------------------发布信息     */
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
                [dic setObject:parameterOne forKey:@"owner_uid"];
                [dic setObject:parameterThree forKey:@"content"];
                [dic setObject:parameterTWO forKey:@"search_uid"];
                [dic setObject:token forKey:@"token"];
                [manager POST:[NSString stringWithFormat:@"%@/ucenter/appinfo/sendInfo.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                    
                } progress:^(NSProgress * _Nonnull uploadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    NSLog(@"%@",error.localizedFailureReason);
                }];
            }
                break;
            case 31:
            {
#pragma mark   ----------------------------------------------------已读未读列表     */
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/appinfo/InfoList.html?token=%@&isread=%@&page=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 32:
            {
#pragma mark   ----------------------------------------------------已读未读列表     */
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/appinfo/unreadInfoSum.html?token=%@", RequestDuanKou,token];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            case 33:
            {
#pragma mark   ----------------------------------------------------已读未读列表     */
                NSString *aa = [NSString stringWithFormat:@"%@/ucenter/appinfo/infoDetail.html?token=%@&search_uid=%@&page=%@", RequestDuanKou,token,parameterOne,parameterTWO];
                
                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                    
                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                    compeletion(YES,responseObject);
                    
                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                    failure(error);
                }];
            }
                break;
            default:
                break;
        }
    }
    
}
#pragma mark   >--------------------<  **  行业圈请求 **  >------------------------------>>
+(void)industryRequestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    
    NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    
    AFHTTPSessionManager *manager = [Helper helperForManager];
    switch (distinguish) {
        case 1:
        {
#pragma mark   ----------------------------------------------------行业圈分类数据请求         ***********/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/tiebatypelist.html?token=%@", RequestDuanKou,token];
            
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 2:
        {
#pragma mark   ----------------------------------------------------行业圈分类数据请------
            NSString *aa = @"";
            if (token.length>0) {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/tiebatypelistbytype.html?token=%@", RequestDuanKou,token];
            }else
            {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/tiebatypelistbytype.html", RequestDuanKou];
            }
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 3:
        {
#pragma mark   ----------------------------------------------------行业圈分类数据请求         ***********/
            
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/following.html?forumid=%@&token=%@", RequestDuanKou,parameterOne,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 4:
        {
#pragma mark   ----------------------------------------------------我加入的贴吧数据请求         ***********/
            
            NSString *aa =[NSString stringWithFormat:@"%@/Forum/App/%@.html?token=%@", RequestDuanKou,parameterOne,token];
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 5:
        {
#pragma mark   ----------------------------------------------------根据贴吧id 获取贴吧帖子请求         ***********/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/Appforum/forumPostListNew.html?forumid=%@&page=%@&pagesize=%@&token=%@", RequestDuanKou,parameterOne,parameterTWO,parameterThree,token];
            if (token.length>0) {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/forumPostList.html?forumid=%@&page=%@&pagesize=%@&token=%@", RequestDuanKou,parameterOne,parameterTWO,parameterThree,token];
            }else
            {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/forumPostList.html?forumid=%@&page=%@&pagesize=%@", RequestDuanKou,parameterOne,parameterTWO,parameterThree];
            }
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 6:
        {
#pragma mark   ----------------------------------------------------帖子详情数据请求         ***********/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/detail.html?id=%@&token=%@", RequestDuanKou,parameterOne,token];
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 7:
        {
#pragma mark   ----------------------------------------------------发帖子接口   ***************/
            /**
             *  @"http://192.168.1.132"
             @"132ea04868468088d8e5129bd14c637a"
             *  @return <#return value description#>
             */
            
            [manager POST:[NSString stringWithFormat:@"%@/Forum/App/addPostnew.html&token=%@",RequestDuanKou,token] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                for (int i=0; i<imageArr.count; i++) {
                    
                    UIImage * imageDatas = imageArr[i];
                    
                    //NSData *imageData = UIImagePNGRepresentation(imageDatas);
                    
                    NSData *imageData = UIImageJPEGRepresentation(imageDatas, 0.1);
                    [formData appendPartWithFileData:imageData
                                                name:[NSString stringWithFormat:@"file%d",i+1]
                                            fileName:[NSString stringWithFormat:@"file%d.png",i]
                                            mimeType:@"image/png"];
                }
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
        }
            break;
        case 8:
        {
#pragma mark   ----------------------------------------------------帖子详情接口   ***************/
            NSString *aa = @"";
            if (token.length>0) {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/detail.html?id=%@&token=%@&page=%@", RequestDuanKou,parameterOne,token,parameterTWO];
            }else
            {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/detail.html?id=%@&page=%@", RequestDuanKou,parameterOne,parameterTWO];
            }
            
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 9:
        {
#pragma mark   ----------------------------------------------------帖子点赞和取消点赞   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/support.html?id=%@&uid=%@&token=%@", RequestDuanKou,parameterOne,parameterTWO,token];
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 10:
        {
#pragma mark   ----------------------------------------------------帖子 删除/加精/置顶  接口   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/%@.html?id=%@&token=%@", RequestDuanKou,parameterTWO,parameterOne,token] ;
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 11:
        {
#pragma mark   ----------------------------------------------------帖子收藏  接口   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/doBookmarknew.html?post_id=%@&&token=%@", RequestDuanKou,parameterOne,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 12:
        {
#pragma mark   ----------------------------------------------------帖子回复楼主  接口   ***************/
            NSDictionary *dic = @{@"postid":parameterOne,@"content":parameterTWO};
            
            /*******     评论数据请求     *******/
            [manager POST:[NSString stringWithFormat:@"%@/Forum/App/doReply.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedDescription);
            }];
        }
            break;
        case 13:
        {
#pragma mark   ----------------------------------------------------帖子回复的回复  接口   ***************/
            NSLog(@"%@",contentDit);
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/LZLReply.html?postid=%@&replyid=%@&lzlid=%@&touid=%@&content=%@&token=%@",RequestDuanKou,[contentDit objectForKey:@"postid"],[contentDit objectForKey:@"replyid"],@"0",[contentDit objectForKey:@"touid"],[contentDit objectForKey:@"content"],token];
            NSString *urlString = [aa stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 14:
        {
#pragma mark   ----------------------------------------------------主题下分类名  接口   ***************/
            
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/App/getForumPostCategoryList.html?forumid=0&token=%@", RequestDuanKou,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 15:
        {
#pragma mark   ----------------------------------------------------按照主题下分类名  获取帖子数据  接口   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/Appforumnew/forumPostList.html?tabid=%@&cateid=%@&token=%@&page=%@", RequestDuanKou,parameterOne,parameterTWO,token,parameterThree];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
            
        case 16:
        {
            
#pragma mark   ----------------------------------------------------供需消息通知数   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/app/noReadMsgCount.html?token=%@", RequestDuanKou,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
            break;
        case 17:
        {
            
#pragma mark   ----------------------------------------------------供需消息通知数据   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/app/getForumMsgList.html?token=%@", RequestDuanKou,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
            break;
        case 18:
        {
            
#pragma mark   ----------------------------------------------------供需消息通知数据   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/app/setNoReadMsgReaded.html?token=%@", RequestDuanKou,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
            break;
        case 19:
        {
#pragma mark   ----------------------------------------------------搜索请求
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            [dic setObject:parameterOne forKey:@"keyword"];
            [dic setObject:parameterTWO forKey:@"forumid"];
            [dic setObject:token forKey:@"token"];
            
            [manager POST:[NSString stringWithFormat:@"%@/Forum/Appforum/forumPostListSou.html?token=%@",RequestDuanKou,token] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
            
            
            
            
            //                NSString *aa = [NSString stringWithFormat:@"%@/news/AppHome/newslist/keywords/%@.html",DuanKou,parameterOne];
            //
            //                [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
            //
            //                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //                    compeletion(YES,responseObject);
            //
            //                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            //                    failure(error);
            //                }];
        }
            break;
        case 20:
        {
#pragma mark   ----------------------------------------------------按照主题下分类名  获取帖子数据  接口   ***************/
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/Appforum/forumPostListRecommend.html?token=%@&page=%@", RequestDuanKou,token,parameterOne];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 21:
        {
#pragma mark   ----------------------------------------------------供需下的分类调取  ***************/
            
            [manager POST:[NSString stringWithFormat:@"%@/Forum/Appforum/forumPostListRecommend.html&token=%@",RequestDuanKou,token] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
            
        }
            break;
        case 22:
        {
#pragma mark   ----------------------------------------------------供需下的分类调取  ***************/
            
            [manager POST:[NSString stringWithFormat:@"%@/Forum/Appforum/forumPostListNear.html?token=%@",RequestDuanKou,token] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
            
        }
            break;
        case 23:
        {
#pragma mark   ----------------------------------------------------帖子收藏  接口   ***************/
            [manager POST:[NSString stringWithFormat:@"%@/Forum/Appforum/followOtherForum.html",RequestDuanKou] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
        }
            break;
        case 24:
        {
#pragma mark   ----------------------------------------------------行业圈用户信息数         ***********/
            
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/Appforum/userDataCollect.html?token=%@", RequestDuanKou,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 25:
        {
#pragma mark   ----------------------------------------------------   ***************/
            
            
            [manager POST:[NSString stringWithFormat:@"%@/Forum/Appforum/userInfoList.html&token=%@",RequestDuanKou,token] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                for (int i=0; i<imageArr.count; i++) {
                    UIImage * imageDatas = imageArr[i];
                    NSData *imageData = UIImageJPEGRepresentation(imageDatas, 0.1);
                    [formData appendPartWithFileData:imageData
                                                name:[NSString stringWithFormat:@"file%d",i+1]
                                            fileName:[NSString stringWithFormat:@"file%d.png",i]
                                            mimeType:@"image/png"];
                }
                
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
        }
            break;
        case 26:
        {
#pragma mark   ----------------------------------------------------用户删除回复
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            [dic setObject:parameterOne forKey:@"id"];
            [dic setObject:token forKey:@"token"];
            
            [manager POST:[NSString stringWithFormat:@"%@/Forum/Appforum/deluserReply.html",RequestDuanKou] parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedFailureReason);
            }];
            
        }
            break;
        case 27:
        {
#pragma mark   ----------------------------------------------------根据贴吧id 获取贴吧帖子请求         ***********/
            NSString *aa = @"";
            if (token.length>0) {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/dropCategoryRefresh.html?forumid=%@&page=%@&type=%@&forumpostid=%@&cateid=%@&token=%@", RequestDuanKou,[contentDit objectForKey:@"forumid"],[contentDit objectForKey:@"page"],[contentDit objectForKey:@"type"],[contentDit objectForKey:@"forumpostid"],[contentDit objectForKey:@"cateid"],token];
            }else
            {
                aa = [NSString stringWithFormat:@"%@/Forum/Appforum/dropCategoryRefresh.html?forumid=%@&page=%@&type=%@&forumpostid=%@&cateid=%@", RequestDuanKou,[contentDit objectForKey:@"forumid"],[contentDit objectForKey:@"page"],[contentDit objectForKey:@"type"],[contentDit objectForKey:@"forumpostid"],[contentDit objectForKey:@"cateid"]];
            }
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 28:
        {
#pragma mark   ----------------------------------------------------行业圈用户信息数         ***********/
            
            NSString *aa = [NSString stringWithFormat:@"%@/Forum/Appforum/dingAndTatolInfo.html?token=%@&forumid=%@&forumpostid=%@", RequestDuanKou,token,parameterOne,parameterTWO];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 29:
        {
#pragma mark   ----------------------------------------------------行业圈用户信息数         ***********/
            
            NSString *aa = [NSString stringWithFormat:@"%@/forum/appforumnew/forumtablist.html", RequestDuanKou];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        default:
            break;
    }
}
int networkID = 0;
+(int)requestNetworkJudgment
{
    
    // 检测网络连接状态
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    // 连接状态回调处理
    /* AFNetworking的Block内使用self须改为weakSelf, 避免循环强引用, 无法释放 */
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case -1:
            {
                networkID = -1;
            }
                break;
            case 0:
            {
                networkID = 0;
            }
                break;
            case 1:
            {
                networkID = 1;
            }
                break;
            case 2:
            {
                networkID = 2;
            }
                break;
                
            default:
                break;
        }
        
    }];
    return networkID;
}
#pragma mark   >--------------------<  **  无图请求 **  >------------------------------>>
+(void)requestStartWithCallOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *responseObject))compeletion failure:(void(^)(NSError *error))failure
{
    
    
    NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    AFHTTPSessionManager *manager = [Helper helperForManager];
    switch (distinguish) {
        case 1:
        {
#pragma mark   ----------------------------------------------------登入请求     *******/
            NSString *invitecode = [userDefault objectForKey:@"invitecode"];
            NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/login.html?username=%@&password=%@&client=%@", RequestDuanKou, parameterOne, parameterTWO,@"ios"] ;
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
            break;
        case 2:
        {
#pragma mark   ----------------------------------------------------退出登入请求     *******/
            NSString *aa = [NSString stringWithFormat:@"%@/ucenter/app/logout.html?token=%@", RequestDuanKou,token];
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 3:
        {
#pragma mark   ----------------------------------------------------圈子数据请求     *******/
            NSString *aa = [NSString stringWithFormat:@"%@/Weibo/App/MyFocusWeiboList.html?page=%@&token=%@", RequestDuanKou,parameterOne,token] ;
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 4:
        {
#pragma mark   ----------------------------------------------------评论数据请求     *******/
            [manager POST:[NSString stringWithFormat:@"%@/Weibo/App/AddComment.html?token=%@",RequestDuanKou,token] parameters:contentDit constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",[responseObject objectForKey:@"message"]);
                compeletion(YES,responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedDescription);
            }];
        }
            break;
        case 5:
        {
#pragma mark   ----------------------------------------------------朋友圈点赞请求     *******/
            NSString *aa =[NSString stringWithFormat:@"%@/Weibo/App/support.html?token=%@&id=%@&targetUid=%@",RequestDuanKou,token,parameterOne,parameterTWO];
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 6:
        {
#pragma mark   ----------------------------------------------------朋友圈点赞请求     *******/
            NSString *aa =@"";
            if (parameterOne.length>0) {
                aa = [NSString stringWithFormat:@"%@/Weibo/App/myweiboList.html?token=%@&targetUid=%@&page=%@",RequestDuanKou,token,parameterOne,parameterTWO];
            }else
            {
                aa = [NSString stringWithFormat:@"%@/Weibo/App/myweiboList.html?token=%@",RequestDuanKou,token];
            }
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 7:
        {
#pragma mark   ----------------------------------------------------登入请求     *******/
            NSString *aa = [NSString stringWithFormat:@"%@/Weibo/App/weiboDetail.html?token=%@&id=%@", RequestDuanKou, token,parameterOne] ;
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
            break;
        case 8:
        {
#pragma mark   ----------------------------------------------------登入请求     *******/
            NSString *aa = [NSString stringWithFormat:@"%@/Weibo/App/delweibo.html?token=%@&id=%@", RequestDuanKou, token,parameterOne] ;
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
            break;
        case 9:
        {
#pragma mark   ----------------------------------------------------朋友圈背景图    *******/
            NSString *aa = [NSString stringWithFormat:@"%@/Weibo/App/getHomePic.html?token=%@&targetUid=%@", RequestDuanKou, token,parameterOne] ;
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
        }
        default:
            break;
            
    }
}
#pragma mark   >--------------------<  **  朋友圈请请求**  >------------------------------>>
+(void)requestImage:(NSArray *)imageArr andOne:(NSString *)parameterOne andTwo:(NSString *)parameterTWO andThree:(NSString *)parameterThree andDitc:(NSDictionary *)contentDit andDistinguish:(int)distinguish success:(void(^)(BOOL state, NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    NSString *token =[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    switch (distinguish) {
        case 1:
        {
            
            NSMutableDictionary *parameters = [[NSMutableDictionary alloc]init];
            [parameters setObject:parameterOne forKey:@"content"];
            [parameters setObject:@"image" forKey:@"type"];
            
#pragma mark   ----------------------------------------------------朋友圈发消息   ***************/
            
            [manager POST:[NSString stringWithFormat:@"%@/Weibo/App/addweibo.html&token=%@",RequestDuanKou,token] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                for (int i=0; i<imageArr.count; i++) {
                    UIImage * imageDatas = imageArr[i];
                    NSData *imageData = UIImageJPEGRepresentation(imageDatas, 0.1);
                    [formData appendPartWithFileData:imageData
                                                name:[NSString stringWithFormat:@"file%d",i+1]
                                            fileName:[NSString stringWithFormat:@"file%d.jpg",i]
                                            mimeType:@"image/jpeg"];
                }
                
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
            
            
        }
            break;
        case 2:
        {
            
#pragma mark   ----------------------------------------------------朋友圈发消息   ***************/
            NSDictionary * parameters = @{@"uid":@"0"};
            [manager POST:[NSString stringWithFormat:@"%@/Ucenter/app/test.html?uid=0",RequestDuanKou] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                for(int i=0 ;i<imageArr.count ;i++)
                {
                    UIImage *images = imageArr[i];
                    NSData *imageData = UIImageJPEGRepresentation(images, 1);
                    [formData appendPartWithFileData:imageData
                                                name:[NSString stringWithFormat:@"file%d",i]
                                            fileName:[NSString stringWithFormat:@"image%d.png",i]
                                            mimeType:@"image/png"];
                }
                
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"22");
                NSLog(@"%@",responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error.localizedDescription);
            }];
        }
            break;
        case 3:
        {
#pragma mark   ----------------------------------------------------朋友圈消息通知
            NSString *aa = [NSString stringWithFormat:@"%@/news/app/getNewsMsgList.html?token=%@",RequestDuanKou,token];
            
            [manager GET:aa parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            break;
        case 4:
        {
            
            NSMutableDictionary *parameters = [[NSMutableDictionary alloc]init];
            
            
#pragma mark   ----------------------------------------------------朋友圈更换背景   ***************/
            
            [manager POST:[NSString stringWithFormat:@"%@//Weibo/App/updateHomePic.html&token=%@",RequestDuanKou,token] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                for (int i=0; i<imageArr.count; i++) {
                    UIImage * imageDatas = imageArr[i];
                    NSData *imageData =  UIImageJPEGRepresentation(imageDatas, 1);
                    [formData appendPartWithFileData:imageData
                                                name:[NSString stringWithFormat:@"file%d",i+1]
                                            fileName:[NSString stringWithFormat:@"file%d.png",i]
                                            mimeType:@"image/png"];
                }
                
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                NSLog(@"11");
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                compeletion(YES,responseObject);
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                failure(error);
            }];
        }
            
        default:
            break;
    }
}
#pragma mark   ----------------------------------------------------上传 修改 认证信息 ***************/
/**
 uid=0   上传认证信息
 uid!=0  修改认证信息
 */

+(void)CertityUPRequestImage:(NSMutableArray *)imageArr andUrl:(NSString *)UrlStr uid:(int)Uid  DataDic:(NSMutableDictionary *)UpDic success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    
    NSString *Url;
    if(Uid==0)
    {
        Url=[NSString stringWithFormat:@"%@?token=%@",UrlStr,TOKEN];
    }else{
        Url=[NSString stringWithFormat:@"%@?token=%@&Id=%d",UrlStr,TOKEN,Uid];
    }
    
    // MHLog(@"--uuuuuuuuuuu--------%@--",Url);
    // MHLog(@"--图片---------%@-",imageArr);
    
    [Manager POST:Url parameters:UpDic  constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        for(int i=0;i<imageArr.count;i++)
        {
            UIImage *Image=imageArr[i];
            NSData *imageData = UIImageJPEGRepresentation(Image, 0.1);
            
            [formData appendPartWithFileData:imageData name:[NSString stringWithFormat:@"pic%d",i] fileName:[NSString stringWithFormat:@"picfile%d.png",i] mimeType:@"image/png"];
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *responseObject) {
        if([responseObject objectForKey:@"status"])
            
        {
            compeletion(YES,nil);
        }else{
            failure(nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}
#pragma mark----------------------------------------------------得到认证信息**************

+(void)GetCertityInforMationWIthSign:(int)Sign Success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    // NSString *uid=[[NSUserDefaults standardUserDefaults] valueForKey:@"uid"];
    
    NSString *Url;
    switch (Sign) {
        case 1:
            Url=@"/kushi/app/GetAuthPersonalInfo";
            break;
        case 2:
            Url=@"/kushi/app/GetAuthFactoryInfo";
            break;
        case 3:
            Url=@"/kushi/app/GetAuthDealerInfo";
            break;
        case 4:
            Url=@"/kushi/app/GetAuthSuperMarketInfo";
            break;
        case 5:
            Url=@"/kushi/app/GetAuthServicersInfo";
            break;
    }
    
    NSString *CertifyId=[[NSUserDefaults standardUserDefaults]objectForKey:CertifyIdStr];
    NSString *UrlStr=[NSString stringWithFormat:@"%@%@?token=%@&Id=%@",MINEDUANKOU,Url,TOKEN,CertifyId];
    // MHLog(@"-----产品--%@",UrlStr);
    
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    [Manager GET:UrlStr parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if([responseObject[@"status"] intValue]==1)
        {
            NSDictionary *dic=responseObject[@"data"];
            compeletion(YES,dic);
        }else{
            NSError *error;
            failure(error);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

#pragma mark ------------------------------------------------------收藏   取消收藏 ***************

+(void)CollectionviewArticleID:(NSString *)ArticleID andUrl:(NSString *)UrlStr success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    
    NSString *token=[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    NSString *Url=[NSString stringWithFormat:@"%@%@news_id/%@?token=%@",RequestDuanKou,UrlStr,ArticleID,token];
    
    // MHLog(@"--请求---%@",Url);
    [Manager GET:Url parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
        compeletion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}
#pragma mark ----------------------------------------------------得到店铺信息***************/
+(void)GetStoreInformationWIthStoreID:(NSString *)StoreID success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    NSString *token=[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    
    NSString *url=[NSString stringWithFormat:@"%@/kushi/App/ShopShow?token=%@&ShopId=%@",MINEDUANKOU,token,StoreID];
    //MHLog(@"--%@--",url);
    
    [Manager POST:url parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
        MHLog(@"--%@--",responseObject);
        
        compeletion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}
#pragma mark   ----------------------------------------------------创建  修改店铺信息***************/
+(void)CreatStroeInformationWith:(UIImage *)StroreImage StroreID:(NSString *)StroeID Dictionary:(NSDictionary *)ParameterDic success:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    
    NSString *urlStr;
    
    if(StroeID==nil)
    {
        urlStr=[NSString stringWithFormat:@"%@/kushi/App/ShopAdd?token=%@",MINEDUANKOU,TOKEN];//创建shop
    }else{
        urlStr=[NSString stringWithFormat:@"%@/kushi/App/ShopAdd?token=%@&Shopid=%@",MINEDUANKOU,TOKEN,StroeID];        //修改Shop
    }
    //    MHLog(@"----%@-----",urlStr);
    //    MHLog(@"----返回的数据111----%@-",ParameterDic);
    
    [Manager POST:urlStr parameters:ParameterDic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        if(StroreImage!=nil)
        {
            NSData *imageData=UIImageJPEGRepresentation(StroreImage, 0.1);
            [formData appendPartWithFileData:imageData name:@"ShopAvatar" fileName:@"ShopAvatar.png" mimeType:@"image/png"];
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *responseObject) {
        
        //标志店铺已经创建成功
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"IfCreatShop"];
        
        compeletion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
        MHLog(@"-cuowu--%@",error);
    }];
}
#pragma mark   ----------------------------------------------------得到产品列表**************
+(void)GetProductListWith:(NSMutableDictionary *)Dic successx:(void(^)(BOOL state,NSDictionary *resultDict))compeletion failure:(void(^)(NSError *error))failure
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    NSString *token=[[NSUserDefaults standardUserDefaults]objectForKey:@"token"];
    NSString *UrlStr=[NSString stringWithFormat:@"%@/kushi/App/ProductList?token=%@",MINEDUANKOU,token];
    
    //    MHLog(@"-------%@--",UrlStr);
    //    MHLog(@"-----%@-",Dic);
    //
    [Manager POST:UrlStr parameters:Dic progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
        
        //  MHLog(@"-----%@--",responseObject);
        
        compeletion(YES,responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}
#pragma mark   ----------------------------------------------------得到产品详情***************/
+(void)GetProductInformationWithProductId:(NSString *)productID  ShopId:(NSString *)ShopId success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    
    NSString *UrlStr=[NSString stringWithFormat:@"%@/kushi/App/ProductShow?token=%@&ShopId=%@&ProductId=%@",MINEDUANKOU,TOKEN,ShopId,productID];
    
    // MHLog(@"-----------------------%@",UrlStr);
    [Manager POST:UrlStr parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {
        compeletion(YES,responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

+(void)GetProductTalkWIth:(NSDictionary *)ParameterDic success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager=[AFHTTPSessionManager manager];
    
    NSString *token=[[NSUserDefaults standardUserDefaults]objectForKey:@"token"];
    NSString *UrlStr=[NSString stringWithFormat:@"%@/kushi/App/ProductCommentList?token=%@",MINEDUANKOU,token];
    NSLog(@"_---%@",UrlStr);
    
    [manager POST:UrlStr parameters:ParameterDic progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        compeletion (YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

+(void)IfCollectStoreWithUrl:(NSString *)UrlStr ShopId:(int)ShopId success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager=[AFHTTPSessionManager manager];
    NSString *Url=[NSString stringWithFormat:@"%@%@?token=%@&ShopId=%d",MINEDUANKOU,UrlStr,TOKEN,ShopId];
    
    [manager POST:Url parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        compeletion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

+(void)GetCustomerLeaveMessageWithShopId:(int)ShopId Page:(int)page success:(void (^)(BOOL, NSDictionary *))compeletion failure:(void (^)(NSError *))failure
{
    AFHTTPSessionManager *manager=[AFHTTPSessionManager manager];
    NSString *token=[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    
    NSString *Url;
    
    Url=[NSString stringWithFormat:@"%@/kushi/App/GuestMessageList?token=%@&shopid=%d&Page=%d&Rows=10",MINEDUANKOU,token,ShopId,page];
    
    //MHLog(@"--%@--",Url);
    [manager POST:Url parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        compeletion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

+(void)JudgeCertifyStatesuccess:(void(^)(int result))Complete
{
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    int sign=[[[NSUserDefaults standardUserDefaults] objectForKey:@"usersign"] intValue];
    NSString *token=[[NSUserDefaults standardUserDefaults] objectForKey:@"token"];
    
    NSString *UrlStr;
    switch (sign) {
        case 4:
            UrlStr=@"/kushi/app/IsAuthPersonal";
            break;
        case 5:
            UrlStr=@"/kushi/app/IsAuthFactory";
            break;
        case 6:
            UrlStr=@"/kushi/app/IsAuthDealer";
            break;
        case 7:
            UrlStr=@"/kushi/app/IsAuthSuperMarket";
            break;
        case 8:
            UrlStr=@"/kushi/app/IsAuthServicers";
            break;
    }
    
    [Manager POST:[NSString stringWithFormat:@"%@%@?token=%@",MINEDUANKOU,UrlStr,token] parameters:nil progress:^(NSProgress * _Nonnull uploadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *responseObject) {
        //字段不准确
        int Result=[responseObject[@"status"] intValue];
        Complete(Result);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    }];
}

#pragma mark- 招商专场 糖酒会列表
+(void)FindSugarGetInforListWithDic:(NSMutableDictionary *)UpDic success:(void(^)(BOOL state,NSDictionary *resultDict))compleletion failure:(void(^)(NSError *error))failure
{
    NSString *token=[[NSUserDefaults standardUserDefaults]objectForKey:@"token"];
    if(token.length>0)
    {
        [UpDic setObject:token forKey:@"token"];
    }
    NSString *StrUrl=[NSString stringWithFormat:@"%@/news/appfind/categoryList.html",RequestDuanKou];
    //NSLog(@"----%@-",StrUrl);
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    
    //    [Manager POST:StrUrl parameters:UpDic progress:^(NSProgress * _Nonnull uploadProgress) {
    //
    //    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
    //        compleletion(YES,responseObject);
    //
    //    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    //        failure(error);
    //
    //    }];
    //
    
    [Manager GET:StrUrl parameters:UpDic progress:^(NSProgress * _Nonnull downloadProgress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        compleletion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}
#pragma mark- 招商专场 糖酒会展会详情
+(void)FindSugarGetDetailInforMationWIth:(NSDictionary *)Updic success:(void (^)(BOOL state, NSDictionary *))Completion failure:(void (^)(NSError *))failure
{
    NSString *StrUrl=[NSString stringWithFormat:@"%@/news/appfind/infoDetail.html",RequestDuanKou];
    //NSLog(@"----%@-",StrUrl);
    
    AFHTTPSessionManager *Manager=[AFHTTPSessionManager manager];
    [Manager POST:StrUrl parameters:Updic progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //  MHLog(@"====%@=",responseObject);
        Completion(YES,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    
}


@end






















