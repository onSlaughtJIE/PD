//
//  LoginViewController.h
//  酷食科技
//
//  Created by dahaoge on 15/12/31.
//  Copyright © 2015年 dahaoge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController<UITextFieldDelegate>
@property (copy, nonatomic) NSString *isReturn;
@property (assign,nonatomic)CGFloat IfGetBackRoot;
@end
