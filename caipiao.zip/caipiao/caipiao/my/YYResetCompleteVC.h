//
//  YYResetCompleteVC.h
//  酷食科技
//
//  Created by 酷食科技 on 16/12/28.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYResetCompleteVC : UIViewController

@end
