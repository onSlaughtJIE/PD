//
//  RegisterViewController.h
//  酷食科技
//
//  Created by dahaoge on 16/1/4.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"
@interface RegisterViewController :LoginViewController

@end
