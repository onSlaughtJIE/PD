//
//  GetPassWordViewController.m
//  酷食科技
//
//  Created by dahaoge on 16/2/29.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "GetPassWordViewController.h"
#import "completeBackVC.h"

@interface GetPassWordViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *authCode;
@property (weak, nonatomic) IBOutlet UITextField *passWord;
@property (weak, nonatomic) IBOutlet UITextField *newspassWord;
@property (strong, nonatomic)UILabel *secondsLabel;
@property (assign, nonatomic)NSInteger seconds;
@property (strong, nonatomic)NSTimer *currenttimer;
@property (weak, nonatomic) IBOutlet UIButton *authCodeButton;
- (IBAction)nextAction:(id)sender;

@end

@implementation GetPassWordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.seconds = 60;
    self.phoneNumber.delegate = self;
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"重置密码";
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
#pragma mark -获取验证码
- (IBAction)getAuthCode:(UIButton *)sender {
    
    //UI配置
    if([_phoneNumber.text isEqualToString:@""])
    {
        [self showHint:@"请输入需要重置的手机号"];
    }else
    {
        [self.authCodeButton setBackgroundColor:UIColorFromRGB(0xcccccc)];
        self.secondsLabel = [[UILabel alloc] initWithFrame:sender.bounds];
        self.secondsLabel.backgroundColor = sender.backgroundColor;
        self.secondsLabel.textColor = [UIColor whiteColor];
        self.secondsLabel.textAlignment = NSTextAlignmentCenter;
        self.secondsLabel.text = [NSString stringWithFormat:@"%ld秒后重发", self.seconds];
        self.secondsLabel.adjustsFontSizeToFitWidth = YES;
        [sender addSubview:self.secondsLabel];
        self.currenttimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changgeSeconds) userInfo:nil repeats:YES];
        [self.authCodeButton setEnabled:NO];
        [self.authCodeButton setTitle:@"重新获取" forState:UIControlStateNormal];
    }
}
- (void)changgeSeconds{
    self.secondsLabel.text = [NSString stringWithFormat:@"%ld秒后重发", --self.seconds];
    if (self.seconds == 0) {
        [self.authCodeButton setEnabled:YES];
        [self.currenttimer invalidate];
        [self.secondsLabel removeFromSuperview];
        self.seconds = 60;
    }
    
}
- (void)inputPhoneNumber{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
- (IBAction)resetPasswordAction:(UIButton *)sender {
    
    if ([self.phoneNumber.text isEqualToString:@"18837179155"]) {
        //跳转到完成界面
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        completeBackVC *completeRegister = [sb instantiateViewControllerWithIdentifier:@"completeBackVC"];
        completeRegister.userName = _phoneNumber.text;
        [self.navigationController pushViewController:completeRegister animated:YES];
        return;
    }
    
    }

- (IBAction)nextAction:(id)sender {
    
    
    
}


- (void)alertWithStatus:(NSInteger)status withMessage:(NSString *)message{
    // NSInteger status = [responseObject[@"status"] intValue];
   
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length>9) {
        [self.authCodeButton setBackgroundColor:sxyColor];
    }else
    {
        [self.authCodeButton setBackgroundColor:UIColorFromRGB(0xcccccc)];
    }
    return YES;
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    //[self.navigationController pushViewController:segue.destinationViewController animated:YES];
    MHLog(@"mahao");
}
@end
