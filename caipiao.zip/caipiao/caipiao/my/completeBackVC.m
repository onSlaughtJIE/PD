//
//  completeBackVC.m
//  酷食科技
//
//  Created by 酷食科技 on 16/6/21.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "completeBackVC.h"
#import "YYResetCompleteVC.h"

@interface completeBackVC ()
@property (weak, nonatomic) IBOutlet UITextField *userPassWord;
@property (weak, nonatomic) IBOutlet UITextField *confirmUserPassWord;
@end

@implementation completeBackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"重置密码";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (IBAction)nextStepAction:(UIButton *)sender {
    
    /**
     *  找回密码请求
     */
   
    
}
@end
