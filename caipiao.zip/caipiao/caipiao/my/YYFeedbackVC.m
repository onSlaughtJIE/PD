//
//  YYFeedbackVC.m
//  酷食科技
//
//  Created by 酷食科技 on 17/4/13.
//  Copyright © 2017年 dahaoge. All rights reserved.
//

#import "YYFeedbackVC.h"

@interface YYFeedbackVC ()
@property(nonatomic,strong)UITextField *feedContentLB;
@property(nonatomic,strong)UITextField *feedPhoneLB;
@end

@implementation YYFeedbackVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = [self reightButtonItem];
    
    [self setMainView];
}
-(void)setMainView
{
    UITextField *feedContentLB = [[UITextField alloc] initWithFrame:CGRectMake(20, 20+64, screenW-40, 200)];
    feedContentLB.placeholder = @"请填写你的需求和建议,给你带来更好的体验! ";
    feedContentLB.layer.cornerRadius = 5;
    feedContentLB.layer.borderColor = UIColorFromRGB(0x999999).CGColor;
    feedContentLB.layer.borderWidth = 1;
    [self.view addSubview:feedContentLB];
    _feedContentLB = feedContentLB;
    UITextField *feedPhoneLB = [[UITextField alloc] initWithFrame:CGRectMake(20, 230+64, screenW-40, 40)];
    feedPhoneLB.placeholder = @" 联系方式 (手机或邮箱)";
    feedPhoneLB.layer.cornerRadius = 5;
    feedPhoneLB.layer.borderColor = UIColorFromRGB(0x999999).CGColor;
    feedPhoneLB.layer.borderWidth = 1;
    [self.view addSubview:feedPhoneLB];
    _feedPhoneLB = feedPhoneLB;
}
-(UIBarButtonItem *)reightButtonItem
{
    UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 25, 60, 30)];
    [rightButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rightButton setTitle:@"提交" forState:UIControlStateNormal];
    [rightButton.layer setCornerRadius:5];
    [rightButton setBackgroundColor:sxyColor];
    
    [rightButton addTarget:self action:@selector(rightbuttonItemClick) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    return rightButtonItem;
    
}
-(void)rightbuttonItemClick
{
    if (_feedContentLB.text.length == 0) {
        [self showHint:@"意见内容不能为空!"];
        return;
    }
    if (_feedPhoneLB.text.length == 0) {
        [self showHint:@"联系方式不能为空!"];
        return;
    }
    
    
    [self startRequests:self.view];
    [requestClass newconsultingRequestImage:nil andOne:nil andTwo:nil andThree:nil andDitc:nil andDistinguish:5 success:^(BOOL state, NSDictionary *resultDict) {
        [self endRequests:self.view];
        [self showHint:@"谢谢你给我们提供的宝贵意见^_^"];
    } failure:^(NSError *error) {
        
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end
