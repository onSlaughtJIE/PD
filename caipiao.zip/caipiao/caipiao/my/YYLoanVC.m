//
//  YYLoanVC.m
//  酷食科技
//
//  Created by 酷食科技 on 17/3/30.
//  Copyright © 2017年 dahaoge. All rights reserved.
//

#import "YYLoanVC.h"
#import <JavaScriptCore/JavaScriptCore.h>
@interface YYLoanVC ()<UIWebViewDelegate>

@end

@implementation YYLoanVC

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
