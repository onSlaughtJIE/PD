//
//  completeRegisterVC.m
//  酷食科技
//
//  Created by 酷食科技 on 16/6/21.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "completeRegisterVC.h"
#import "LoginViewController.h"
#import "YYMyVC.h"

@interface completeRegisterVC ()
@property (weak, nonatomic) IBOutlet UITextField *userPassWord;
@property (weak, nonatomic) IBOutlet UITextField *confirmUserPassWord;
@end

@implementation completeRegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"注册";
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)nextStepAction:(UIButton *)sender {
    if([_userName isEqualToString:@"18837179155"])
    {
        
        //        NSArray *arrVC = self.navigationController.viewControllers;
        //        UIViewController *vc = arrVC[arrVC.count-3];
        //        [self.navigationController popToViewController:vc animated:YES];
        
        NSArray *arr= self.navigationController.viewControllers;
        for (UIViewController *vc in arr) {
            if ([vc isKindOfClass:[YYMyVC class]]) {
                if([[userDefault objectForKey:@"logintype"] isEqualToString:@"1"])
                {
                    [self showHint:@"注册成功"];
                    [userDefault setObject:_userName forKey:@"name"];
                }else
                {
                    [self showHint:@"重置密码成功"];
                }
                
                [self.navigationController popToViewController:vc animated:YES];
                return;
            }
        }
        
    }
    
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

@end
