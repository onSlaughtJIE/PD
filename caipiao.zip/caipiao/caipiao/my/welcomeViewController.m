//
//  welcomeViewController.m
//  酷食科技
//
//  Created by 酷食科技 on 16/4/25.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import "welcomeViewController.h"
#import "LoginViewController.h"

@interface welcomeViewController ()

@end

@implementation welcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController pushViewController:[LoginViewController new] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
