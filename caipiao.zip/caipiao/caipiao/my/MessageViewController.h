//
//  MessageViewController.h
//  酷食科技
//
//  Created by dahaoge on 16/3/3.
//  Copyright © 2016年 dahaoge. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^Message)(NSInteger messageNumber);

@interface MessageViewController : UITableViewController
@property(nonatomic, strong)NSMutableArray *messageArray;
@property(nonatomic, copy)Message message;
@end
