//
//  YYListVC.h
//  sasa
//
//  Created by 挣钱宝 on 17/4/15.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYListVC : UITableViewController

@end
