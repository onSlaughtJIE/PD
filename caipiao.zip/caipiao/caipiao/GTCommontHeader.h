//
//  GTCommontHeader.h
//
//  Created by GuanTian Li on 14-10-5.
//  Copyright (c) 2015年 GCI. All rights reserved.
//
/**
 *   4s--6plus适配 以iphone5屏幕为适配基础
 *

 */
#import <UIKit/UIKit.h>

#ifndef iphone6_Fix_Demo_GTCommontHeader_h
#define iphone6_Fix_Demo_GTCommontHeader_h


CG_INLINE CGFloat GTFixHeightFlaot(CGFloat height) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        if (mainFrme.size.height<568) {
            return height*480/568;
        }
        return height;
    }
    height = height*mainFrme.size.height/1096*2;
    return height;
}
CG_INLINE CGFloat GTFixLeftFlaot(CGFloat left) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        return left;
    }
    left = left*mainFrme.size.height/1096*2;
    return left;
}
CG_INLINE CGFloat GTFixRightFlaot(CGFloat Right) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        if (mainFrme.size.height<568) {
            return Right*480/568;
        }
        return Right;
    }
    Right = Right*mainFrme.size.width/622*2;
    return Right;
}
CG_INLINE CGFloat GTReHeightFlaot(CGFloat height) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        if (mainFrme.size.height<568) {
            return height*480/568;
        }
        return height;
    }
    height = height*1096/(mainFrme.size.height*2);
    return height;
}

CG_INLINE CGFloat GTFixWidthFlaot(CGFloat width) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        return width;
    }
    width = width*mainFrme.size.width/640*2;
    return width;
}
//处理4s 元头像
CG_INLINE CGFloat GTFixWidthsFlaot(CGFloat width) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        if (mainFrme.size.height<568) {
            return width*480/568;
        }
        return width;
    }
    width = width*mainFrme.size.width/640*2;
    return width;
}
CG_INLINE CGFloat GTFixHeightsFlaot(CGFloat Height) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        if (mainFrme.size.height<568) {
            return Height*480/568;
        }
        return Height;
    }
    Height = Height*mainFrme.size.width/640*2;
    return Height;
}
CG_INLINE CGFloat GTReWidthFlaot(CGFloat width) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    if (mainFrme.size.height/1096*2 < 1) {
        return width;
    }
    width = width*640/mainFrme.size.width/2;
    return width;
}
CG_INLINE CGRect
GTRectMake(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    rect.origin.x = GTFixLeftFlaot(x);
    rect.origin.y = GTFixRightFlaot(y);
    rect.size.width = GTFixWidthFlaot(width); rect.size.height = GTFixHeightsFlaot(height);
    return rect;
}
CG_INLINE CGRect
GTRectMaked(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    rect.origin.x = GTFixLeftFlaot(x);
    rect.origin.y = y;
    rect.size.width = GTFixWidthFlaot(width); rect.size.height = GTFixHeightsFlaot(height);
    return rect;
}
CG_INLINE CGRect
GTRectMakes(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    rect.origin.x = GTFixLeftFlaot(x);
    rect.origin.y = y;
    rect.size.width = GTFixWidthFlaot(width); rect.size.height = GTFixHeightsFlaot(height);
    return rect;
}
CG_INLINE CGRect
GTRectMakef(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    rect.origin.x = GTFixLeftFlaot(x);
    rect.origin.y = GTFixRightFlaot(y);
    rect.size.width = GTFixWidthFlaot(width); rect.size.height = height;
    return rect;
}
//处理4s 元头像
//处理字体
CG_INLINE CGFloat GTFondWidthFlaot(CGFloat width) {
    CGRect mainFrme = [[UIScreen mainScreen] applicationFrame];
    
    if (mainFrme.size.height/1400*2 < 1) {
        return width;
    }
    width = width*1.1;
    return width;
}
#endif
