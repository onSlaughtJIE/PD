//
//  CPWebViewController.h
//  caipiao
//
//  Created by Chao on 2017/3/21.
//  Copyright © 2017年 Next. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPWebViewController : UIViewController

@property (nonatomic, copy) NSString *urlStr;

@end
