//
//  YYFistDetailVC.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYFistDetailVC.h"
#import "YYFistCell.h"

#import "YYLoctionDetailDataVC.h"

@interface YYFistDetailVC ()<YYFistCellDelegate,UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSMutableArray *describe;
@property(nonatomic,strong)NSMutableArray *leftdescribeArr;
@property(nonatomic,strong)UITableView *tableView;
@end

@implementation YYFistDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = ViewBackgroundColor;
    [self creatData];
    
    
    self.navigationItem.rightBarButtonItem = [self creatUIbarbutton];
    self.navigationController.navigationBar.tintColor = sxyColor;
    [self.view addSubview:self.tableView];
    [self toobView];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager POST:@"http://mobile.aicai.com/info/lastopen.do" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        NSLog(@"11");
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"22");
        NSLog(@"%@",[responseObject objectForKey:@"message"]);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error.localizedDescription);
    }];
    
    [[UIApplication sharedApplication]setApplicationSupportsShakeToEdit:YES];
    
    [self becomeFirstResponder];
}
-(UIBarButtonItem *)creatUIbarbutton
{
    UIButton *releaseButton = [[UIButton alloc] initWithFrame:CGRectMake(-100, 0, 70, 25)];
    
    [releaseButton setBackgroundColor:sxyColor];
    releaseButton.titleLabel.font = [UIFont systemFontOfSize:12];
    releaseButton.tag = 200;
    [releaseButton addTarget:self action:@selector(alreadyCompleteaction) forControlEvents:UIControlEventTouchUpInside];
    [releaseButton.layer setCornerRadius:5];
    [releaseButton setTitle:@"摇一摇选号" forState:normal];
    UIBarButtonItem *releaseButtonItem = [[UIBarButtonItem alloc] initWithCustomView:releaseButton];
    return releaseButtonItem;
    
}
-(void)toobView
{
    UIToolbar *boolb = [[UIToolbar alloc] initWithFrame:CGRectMake(0, ScreemH-40, ScreemW, 40)];
    boolb.backgroundColor = [UIColor whiteColor];
    
    for (int i=0; i<3; i++) {
        UIButton *bt = [[UIButton alloc] initWithFrame:CGRectMake(i*ScreemW/3, 0, ScreemW/3, 40)];
        if (i==0) {
            [bt setBackgroundColor:sxyColor];
            [bt setTitle:@"保存" forState:UIControlStateNormal];
        }else if (i==1)
        {
            [bt setBackgroundColor:UIColorFromRGB(0x333333)];
            [bt setTitle:@"清楚选择" forState:UIControlStateNormal];
        }else
        {
            [bt setBackgroundColor:sxyColor];
            [bt setTitle:@"查看保存" forState:UIControlStateNormal];
        }
        [bt addTarget:self action:@selector(btClick:) forControlEvents:UIControlEventTouchUpInside];
        bt.tag = i;
        [boolb addSubview:bt];
    }
    
    [self.view addSubview:boolb];
}
-(void)btClick:(UIButton *)bt
{
    if (bt.tag == 0) {
        //保存
        if ([[userDefault objectForKey:@"name"] isEqualToString:@"1"] || [userDefault objectForKey:@"name"] == nil) {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"温馨提示                           " message:@"请先去我的中心登录才能保存                           谢谢^_^" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
                
            }];
            [alert addAction:action1];
            
            [self presentViewController:alert animated:YES completion:nil];
        }else
        {
            switch (_type) {
                case 0:
                {
                    //双色球
                    
                    [self creadLoctionData];
                }
                    break;
                case 1:
                {
                    //大乐秀
                    [self creadLoctionData];
                }
                    break;
                case 2:
                {
                    //时时彩
                    [self creadLoctionData];
                }
                    break;
                case 3:
                {
                    //七星彩
                    [self creadLoctionType2Data];
                }
                    break;
                case 4:
                {
                    //福彩三地
                    [self creadLoctionType2Data];
                }
                    break;
                case 5:
                {
                    //11选5
                    [self creadLoctionType2Data];
                }
                    break;
                case 6:
                {
                    //排列3
                    [self creadLoctionType2Data];
                }
                    break;
                case 7:
                {
                    //排列5=
                    [self creadLoctionType2Data];
                }
                    break;
                    
                default:
                    break;
            }
        }
        
        
    }else if (bt.tag ==1)
    {
        [self creatData];
    }else
    {
        YYLoctionDetailDataVC *loction = [YYLoctionDetailDataVC new];
        loction.title = @"选号记录";
        loction.view.backgroundColor = ViewBackgroundColor;
        [self.navigationController pushViewController:loction animated:YES];
    }
}
- (void) motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event

{
    
    //检测到摇动开始
    
    if (motion == UIEventSubtypeMotionShake)
        
    {
        [self alreadyCompleteaction];
    }
    
}
-(void)alreadyCompleteaction
{
    [self creatData];
    
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.1];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.2];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.3];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.4];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.5];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.6];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.7];
    [self performSelector:@selector(sleeepClick) withObject:self afterDelay:0.8];
    
}
-(void)sleeepClick
{
    switch (_type) {
        case 0:
        {
            //双色球
            [self creatData];
            [self rancomWithStart:1 andEnd:33 andRancomNummber:6 andRow:0];
            [self rancomWithStart:1 andEnd:16 andRancomNummber:1 andRow:1];
        }
            break;
        case 1:
        {
            //大乐秀
            [self creatData];
            [self rancomWithStart:1 andEnd:35 andRancomNummber:5 andRow:0];
            [self rancomWithStart:1 andEnd:12 andRancomNummber:2 andRow:1];
        }
            break;
        case 2:
        {
            //时时彩
            [self creatData];
            [self rancomWithStart:1 andEnd:42 andRancomNummber:7 andRow:0];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:2 andRow:1];
        }
            break;
        case 3:
        {
            //七星彩
            [self creatData];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:0];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:1];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:2];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:3];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:4];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:5];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:6];
        }
            break;
        case 4:
        {
            //福彩三地
            [self creatData];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:0];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:1];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:2];
            
        }
            break;
        case 5:
        {
            //11选5
            [self creatData];
            [self rancomWithStart:1 andEnd:11 andRancomNummber:5 andRow:0];
        }
            break;
        case 6:
        {
            //排列3
            [self creatData];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:0];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:1];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:2];
        }
            break;
        case 7:
        {
            //排列5
            [self creatData];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:0];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:1];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:2];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:3];
            [self rancomWithStart:1 andEnd:9 andRancomNummber:1 andRow:4];
        }
            break;
            
        default:
            break;
    }
    
}
-(void)creatData
{
    switch (_type) {
        case 0:
        {
            //双色球
            [self creadDataWithNummber:33 andRowNummber:2];
            [self.describe removeAllObjects];
            
            [self.describe addObject:@"至少选6个红球"];
            [self.describe addObject:@"至少选1个蓝球"];
            [self.leftdescribeArr removeAllObjects];
            [self.leftdescribeArr addObject:@"红球"];
            [self.leftdescribeArr addObject:@"篮球"];
        }
            break;
        case 1:
        {
            //大乐秀
            [self creadDataWithNummber:35 andRowNummber:2];
            [self.describe removeAllObjects];
            [self.describe addObject:@"至少选5个红球"];
            [self.describe addObject:@"至少选2个蓝球"];
            [self.leftdescribeArr removeAllObjects];
            [self.leftdescribeArr addObject:@"红球"];
            [self.leftdescribeArr addObject:@"篮球"];
        }
            break;
        case 2:
        {
            //时时彩
            [self creadDataWithNummber:42 andRowNummber:2];
            [self.describe removeAllObjects];
            [self.describe addObject:@"至少选7个红球"];
            [self.describe addObject:@"至少选2个蓝球"];
            
            [self.leftdescribeArr removeAllObjects];
            [self.leftdescribeArr addObject:@"红球"];
            [self.leftdescribeArr addObject:@"篮球"];
        }
            break;
        case 3:
        {
            //七星彩
            [self creadDataWithNummber:9 andRowNummber:7];
            [self.describe removeAllObjects];
            [self.leftdescribeArr removeAllObjects];
            for (int i=1; i<8; i++) {
                [self.leftdescribeArr addObject:[NSString stringWithFormat:@"第%d位",i]];
                [self.describe addObject:@"至少选1个号"];
            }
        }
            break;
        case 4:
        {
            //福彩三地
            [self creadDataWithNummber:9 andRowNummber:3];
            [self.describe removeAllObjects];
            [self.leftdescribeArr removeAllObjects];
            for (int i=1; i<4; i++) {
                if (i==1) {
                    [self.leftdescribeArr addObject:@"百位"];
                }else if ( i==2)
                {
                    [self.leftdescribeArr addObject:@"十位"];
                }else
                {
                    [self.leftdescribeArr addObject:@"个位"];
                }
                [self.describe addObject:@"至少选1个号"];
            }
            
        }
            break;
        case 5:
        {
            //11选5
            [self creadDataWithNummber:11 andRowNummber:1];
            [self.describe removeAllObjects];
            [self.leftdescribeArr removeAllObjects];
            [self.leftdescribeArr addObject:@"任选"];
            [self.describe addObject:@"至少选5个号"];
        }
            break;
        case 6:
        {
            //排列3
            [self creadDataWithNummber:9 andRowNummber:3];
            [self.describe removeAllObjects];
            [self.leftdescribeArr removeAllObjects];
            for (int i=1; i<4; i++) {
                if (i==1) {
                    [self.leftdescribeArr addObject:@"百位"];
                }else if ( i==2)
                {
                    [self.leftdescribeArr addObject:@"十位"];
                }else
                {
                    [self.leftdescribeArr addObject:@"个位"];
                }
                [self.describe addObject:@"至少选1个号"];
            }
        }
            break;
        case 7:
        {
            //排列5
            [self creadDataWithNummber:9 andRowNummber:5];
            [self.describe removeAllObjects];
            [self.leftdescribeArr removeAllObjects];
            for (int i=1; i<6; i++) {
                if (i==1) {
                    [self.leftdescribeArr addObject:@"万位"];
                }else if ( i==2)
                {
                    [self.leftdescribeArr addObject:@"千位"];
                }else if ( i==3)
                {
                    [self.leftdescribeArr addObject:@"百位"];
                }else if ( i==4)
                {
                    [self.leftdescribeArr addObject:@"十位"];
                }else
                {
                    [self.leftdescribeArr addObject:@"个位"];
                }
                [self.describe addObject:@"至少选1个号"];
            }
        }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)creadDataWithNummber:(NSInteger)btNummber andRowNummber:(NSInteger)RowNummber
{
    [self.dataArr removeAllObjects];
    
    for (int y =0; y<RowNummber; y++) {
        NSMutableArray *arr = [NSMutableArray arrayWithCapacity:0];
        if(y==1 && _type == 0)
        {
            btNummber =16;
        }
        if(y==1 && _type == 1)
        {
            btNummber =12;
        }
        
        if(y==1 && _type == 2)
        {
            btNummber =9;
        }
        for (int i=0; i<btNummber; i++) {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:0];
            [dic setObject:[NSString stringWithFormat:@"%d",i] forKey:@"btTitle"];
            [dic setObject:@"0" forKey:@"btTag"];
            [arr addObject:dic];
        }
        [self.dataArr addObject:arr];
    }
    
    [self.tableView reloadData];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return self.dataArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableArray *arr = self.dataArr[indexPath.row];
    NSInteger cellType = 1;
    if ((_type ==0 || _type == 1 || _type == 2)&& indexPath.row ==1) {
        cellType = 0;
    }
    YYFistCell *cell = [[YYFistCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell" andTypeType:cellType andBTnummber:arr.count];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.delegate = self;
    cell.title = self.describe[indexPath.row];
    cell.leftTitle = self.leftdescribeArr[indexPath.row];
    cell.dataArr = self.dataArr[indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *dataArr = _dataArr[indexPath.row];
    return (dataArr.count-1)/7*((ScreemW-20*8)/7+18)+90;
}
-(void)buttonClickWithSelectId:(NSInteger)selctID andCell:(UITableViewCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    NSMutableArray *buArr = _dataArr[indexPath.row];
    NSDictionary *btDic = buArr[selctID-1];
    NSString *btTag =btDic[@"btTag"];
    if ([btTag isEqualToString:@"1"]) {
        [btDic setValue:@"0" forKey:@"btTag"];
    }else
    {
        [btDic setValue:@"1" forKey:@"btTag"];
    }
    [buArr replaceObjectAtIndex:selctID-1 withObject:btDic];
    [_dataArr replaceObjectAtIndex:indexPath.row withObject:buArr];
    [self.tableView reloadData];
}
-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _dataArr;
}
-(NSMutableArray *)describe
{
    if (!_describe) {
        _describe = [NSMutableArray arrayWithCapacity:0];
    }
    return _describe;
}
-(NSMutableArray *)leftdescribeArr
{
    if (!_leftdescribeArr) {
        _leftdescribeArr = [NSMutableArray arrayWithCapacity:0];
    }
    return _leftdescribeArr;
}
-(UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScreemW, screenH-40)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = NO;
        _tableView.backgroundColor = ViewBackgroundColor;
    }
    return _tableView;
}
-(void)rancomWithStart:(int)start andEnd:(int)end andRancomNummber:(NSInteger)rancomNummber andRow:(NSInteger)rowNummber
{
    NSMutableArray *nummberArr = [NSMutableArray arrayWithCapacity:0];
    for (int i=start; i<end+1; i++) {
        [nummberArr addObject:[NSString stringWithFormat:@"%d",i]];
    }
    for (int i=1; i<rancomNummber+1; i++) {
        int y = arc4random() % end;
        if (y==0) {
            y++;
        }
        [self buttonClickWithSelectId:[nummberArr[y-1] integerValue] andRow:rowNummber];
        [nummberArr removeObjectAtIndex:y-1];
        end--;
        
    }
}
-(void)buttonClickWithSelectId:(NSInteger)selctID andRow:(NSInteger)rowNummber
{
    
    NSMutableArray *buArr = _dataArr[rowNummber];
    NSDictionary *btDic = buArr[selctID-1];
    NSString *btTag =btDic[@"btTag"];
    if ([btTag isEqualToString:@"1"]) {
        [btDic setValue:@"0" forKey:@"btTag"];
    }else
    {
        [btDic setValue:@"1" forKey:@"btTag"];
    }
    [buArr replaceObjectAtIndex:selctID-1 withObject:btDic];
    [_dataArr replaceObjectAtIndex:rowNummber withObject:buArr];
    [self.tableView reloadData];
}
#pragma mark 加载
-(void)startRequests:(UIView *)view andContent:(NSString *)content
{
    MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    //设置对话框文字
    HUD.labelText = content;
    HUD.alpha = 0.5;
    HUD.labelFont = [UIFont systemFontOfSize:15];
    
}
-(void)startRequests:(UIView *)view
{
    MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    //设置对话框文字
    HUD.labelText = @"加载中...";
    HUD.alpha = 0.5;
    HUD.labelFont = [UIFont systemFontOfSize:15];
    
}
-(void)endRequests:(UIView *)view
{
    [MBProgressHUD hideHUDForView:view animated:YES];
}
-(void)creadLoctionType2Data
{
    NSMutableArray *dataArr = [NSMutableArray arrayWithCapacity:0];
    
    NSMutableArray *dataArrs = [userDefault objectForKey:[NSString stringWithFormat:@"%ld",_type]];
    [dataArr addObjectsFromArray:dataArrs];
    NSMutableArray *redArr = [NSMutableArray arrayWithCapacity:0];
    
    for (int i=0;i<self.dataArr.count;i++) {
        NSMutableArray *dataArr = self.dataArr[i];
        for (NSDictionary *dataDic in dataArr) {
            NSString *titleTag = dataDic[@"btTag"];
            if ([titleTag isEqualToString:@"1"]) {
                
                //红球
                [redArr addObject:dataDic[@"btTitle"]];
            }
        }
        
    }
    if (redArr.count == 0) {
        [self showHint:@"请选择记录彩票号"];
    }else
    {
        if (dataArr== nil) {
            NSMutableArray *dataAllArr = [[NSMutableArray alloc] initWithCapacity:0];
            NSMutableDictionary *dataArllDic = [[NSMutableDictionary alloc] initWithCapacity:0];
            
            [dataArllDic setObject:redArr forKey:@"red"];
            [dataAllArr addObject:dataArllDic];
            [userDefault setObject:dataAllArr forKey:[NSString stringWithFormat:@"%ld",_type]];
        }else
        {
            NSMutableDictionary *dataArllDic = [[NSMutableDictionary alloc] initWithCapacity:0];
           
            [dataArllDic setObject:redArr forKey:@"red"];
            [dataArr addObject:dataArllDic];
            [userDefault setObject:dataArr forKey:[NSString stringWithFormat:@"%ld",_type]];
        }
        [self showHint:@"保存成功"];
    }
}
-(void)creadLoctionData
{
    NSMutableArray *dataArr = [NSMutableArray arrayWithCapacity:0];
    
    NSMutableArray *dataArrs = [userDefault objectForKey:[NSString stringWithFormat:@"%ld",_type]];
    [dataArr addObjectsFromArray:dataArrs];
    NSMutableArray *blueArr = [NSMutableArray arrayWithCapacity:0];
    NSMutableArray *redArr = [NSMutableArray arrayWithCapacity:0];
    
    for (int i=0;i<self.dataArr.count;i++) {
        NSMutableArray *dataArr = self.dataArr[i];
        for (NSDictionary *dataDic in dataArr) {
            NSString *titleTag = dataDic[@"btTag"];
            if ([titleTag isEqualToString:@"1"]) {
                
                if(i==0)
                {
                    //红球
                    [redArr addObject:dataDic[@"btTitle"]];
                }else
                {
                    //篮球
                    [blueArr addObject:dataDic[@"btTitle"]];
                }
            }
        }
        
    }
    if (redArr.count == 0 || blueArr.count == 0) {
        [self showHint:@"请选择记录彩票号"];
    }else
    {
        if (dataArr== nil) {
            NSMutableArray *dataAllArr = [[NSMutableArray alloc] initWithCapacity:0];
            NSMutableDictionary *dataArllDic = [[NSMutableDictionary alloc] initWithCapacity:0];
            [dataArllDic setObject:blueArr forKey:@"blue"];
            [dataArllDic setObject:redArr forKey:@"red"];
            [dataAllArr addObject:dataArllDic];
            [userDefault setObject:dataAllArr forKey:[NSString stringWithFormat:@"%ld",_type]];
        }else
        {
            NSMutableDictionary *dataArllDic = [[NSMutableDictionary alloc] initWithCapacity:0];
            [dataArllDic setObject:blueArr forKey:@"blue"];
            [dataArllDic setObject:redArr forKey:@"red"];
            [dataArr addObject:dataArllDic];
            [userDefault setObject:dataArr forKey:[NSString stringWithFormat:@"%ld",_type]];
        }
        [self showHint:@"保存成功"];
    }
}
@end
