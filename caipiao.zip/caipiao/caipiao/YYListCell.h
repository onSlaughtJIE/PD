//
//  YYListCell.h
//  sasa
//
//  Created by 挣钱宝 on 17/4/15.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYListCell : UITableViewCell
@property(nonatomic,strong)NSDictionary *dataDic;
@property(nonatomic,copy)NSString *title;
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andTypeNummber:(NSInteger)lbNummber andcolorNummber:(NSInteger)colorNummber;

@end
