//
//  YYLoctionCell.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYLoctionCell.h"
@interface YYLoctionCell()
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *title;

@end
@implementation YYLoctionCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setTitleContent:(NSString *)titleContent
{
    _image.image = [UIImage imageNamed:titleContent];
    _title.text = titleContent;
}
@end
