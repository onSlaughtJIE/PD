//
//  YYTabBarViewController.m
//  快乐背单词
//
//  Created by 酷食科技 on 16/11/10.
//  Copyright © 2016年 乐学. All rights reserved.
//

#import "YYTabBarViewController.h"



#import "YYNavigationController.h"
#import "cp1.h"
#import "YYListVC.h"
#import "cp3.h"
#import "InvestmentMainPage.h"
#import "YYMyVC.h"
#import "YYCircleVC.h"
@interface YYTabBarViewController ()
@property(nonatomic,strong)YYNavigationController *nav;
@end

@implementation YYTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self addAllChildVcs];
    
    
    
    
}

-(void)addAllChildVcs
{
    InvestmentMainPage *paradiseVC = [InvestmentMainPage new];
    [self addOneChlildVc:paradiseVC title:@"首页" imageName:@"首页" selectedImageName:@"首页点击"];
    YYCircleVC *circle = [YYCircleVC new];
    [self addOneChlildVc:circle title:@"彩坛资讯" imageName:@"资讯" selectedImageName:@"资讯点击"];
    YYListVC *myVC = [YYListVC new];
    [self addOneChlildVc:myVC title:@"开奖01" imageName:@"开奖" selectedImageName:@"开奖点击"];
    cp3 *mj = [cp3 new];
    [self addOneChlildVc:mj title:@"秘籍" imageName:@"秘籍" selectedImageName:@"秘籍点击"];
    
    YYMyVC *my = [YYMyVC new];
    [self addOneChlildVc:my title:@"我的" imageName:@"我的" selectedImageName:@"我的点击"];
}
/**
 *  添加一个子控制器
 *
 *  @param childVc           子控制器对象
 *  @param title             标题
 *  @param imageName         图标
 *  @param selectedImageName 选中的图标
 */
- (void)addOneChlildVc:(UIViewController *)childVc title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    // 设置标题
    childVc.title = imageName;
    // 设置图标
    childVc.tabBarItem.image = [UIImage imageNamed:imageName];
    
    // 设置tabBarItem的普通文字颜色
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.5 green:0.5 blue:0.5199 alpha:1.0];
    textAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:0];
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    // 设置tabBarItem的选中文字颜色
    NSMutableDictionary *selectedTextAttrs = [NSMutableDictionary dictionary];
    //selectedTextAttrs[NSForegroundColorAttributeName] =mainViewColor;
    [childVc.tabBarItem setTitleTextAttributes:selectedTextAttrs forState:UIControlStateSelected];
    // 设置选中的图标
    UIImage *selectedImage = [UIImage imageNamed:selectedImageName];
    
    // 声明这张图片用原图(别渲染)
    selectedImage = [selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    childVc.tabBarItem.selectedImage = selectedImage;
    //    // 添加为tabbar控制器的子控制器
    _nav = [[YYNavigationController alloc] initWithRootViewController:childVc];
    _nav.navigationBar.tintColor = [UIColor grayColor];
    _nav.navigationBar.barTintColor = [UIColor whiteColor];
    
    // 设置 uitabbar 设置 线颜色
    CGRect rect = CGRectMake(0, 0, screenW, 1);
    UIGraphicsBeginImageContext(rect.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context,
                                   UIColorFromRGB(0xd9d9d9).CGColor);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //[self.tabBarItem setTitlePositionAdjustment:UIOffsetMake(15, -20)];
    
    [self.tabBar setShadowImage:img];
    
    [self.tabBar setBackgroundImage:[[UIImage alloc]init]];
    [self addChildViewController:_nav];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
