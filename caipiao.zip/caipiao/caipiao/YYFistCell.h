//
//  YYFistCell.h
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol YYFistCellDelegate<NSObject>

-(void)buttonClickWithSelectId:(NSInteger)selctID andCell:(UITableViewCell *)cell;

@end
@interface YYFistCell : UITableViewCell
@property(nonatomic,weak)id<YYFistCellDelegate>delegate;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *leftTitle;
@property(nonatomic,assign)NSInteger type;
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andTypeType:(NSInteger)type andBTnummber:(NSInteger)btNummber;
@end
