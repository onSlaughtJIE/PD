//
//  YYLoctionNummberDetailVC.m
//  caipiao
//
//  Created by apple on 2017/4/18.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYLoctionNummberDetailVC.h"

@interface YYLoctionNummberDetailVC ()
@property(nonatomic,strong)NSMutableArray *dataArr;
@end

@implementation YYLoctionNummberDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = ViewBackgroundColor;
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _dataArr = [userDefault objectForKey:_type];
    [self.tableView reloadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return _dataArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    NSDictionary *dataDic = _dataArr[indexPath.section];
    NSArray *redArr =[dataDic objectForKey:@"red"];
    NSArray *blueArr =[dataDic objectForKey:@"blue"];
    NSString *nummber = nil;
    NSString *rightNummber = @"";
    NSString *leftNummber = @"";
    if (blueArr.count>0) {
        for (int i=0;i<redArr.count ;i++) {
            if (i==0) {
                nummber = redArr[0];
                rightNummber = redArr[0];
            }
            nummber = [NSString stringWithFormat:@"%@-%@",nummber,redArr[i]];
            rightNummber = [NSString stringWithFormat:@"%@-%@",rightNummber,redArr[i]];
        }
        for (int i=0;i<blueArr.count ;i++) {
            nummber = [NSString stringWithFormat:@"%@-%@",nummber,blueArr[i]];
            leftNummber = [NSString stringWithFormat:@"%@-%@",leftNummber,blueArr[i]];
        }
    }else
    {
        for (int i=0;i<redArr.count ;i++) {
            if (i==0) {
                nummber = redArr[0];
            }
            nummber = [NSString stringWithFormat:@"%@-%@",nummber,redArr[i]];
            rightNummber = [NSString stringWithFormat:@"%@-%@",rightNummber,redArr[i]];
        }
    }
    cell.textLabel.attributedText = [self generateAttributedStringWithCommentItemModel:nummber andLeftContent:rightNummber andColorContent:leftNummber];
    return cell;
}
- (NSMutableAttributedString *)generateAttributedStringWithCommentItemModel:(NSString *)content andLeftContent:(NSString *)leftContent andColorContent:(NSString *)ColorContent
{
    //获取第一评论用户名
    
    NSString *aa = ColorContent;
    
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:content];
    
    [str addAttribute:NSForegroundColorAttributeName value:sxyColor range:NSMakeRange(leftContent.length,aa.length)];
    
    return str;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
