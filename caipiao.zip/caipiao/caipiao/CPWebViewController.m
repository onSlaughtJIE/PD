//
//  CPWebViewController.m
//  caipiao
//
//  Created by Chao on 2017/3/21.
//  Copyright © 2017年 Next. All rights reserved.
//

#import "CPWebViewController.h"
#import <WebKit/WebKit.h>
@interface CPWebViewController ()<WKNavigationDelegate, WKUIDelegate>
@property (nonatomic, strong) WKWebView *webView;
@end

@implementation CPWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
    [self initWebView];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}
#pragma mark - Initialization

- (void)initWebView
{
    self.view.backgroundColor = [UIColor whiteColor];
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    // 设置偏好设置
    WKPreferences *preferences = [[WKPreferences alloc] init];
    // 默认为0
    preferences.minimumFontSize = 10;
    // 默认认为YES
    preferences.javaScriptEnabled = YES;
    // 在iOS上默认为NO，表示不能自动通过窗口打开
    preferences.javaScriptCanOpenWindowsAutomatically = NO;
    config.preferences = preferences;
    // web内容处理池
    config.processPool = [[WKProcessPool alloc] init];
    // 通过JS与webview内容交互
    config.userContentController = [[WKUserContentController alloc] init];
    
    CGRect rect = self.view.bounds;
    _webView = [[WKWebView alloc] initWithFrame:rect configuration:config];
    _webView.navigationDelegate = self;
    [self.view addSubview:_webView];
    _webView.frame = CGRectMake(0, 0, screenW, screenH);
    
    NSURL *url = [NSURL URLWithString:self.urlStr];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:req];
    
    [self startRequests:_webView];
    
}

#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    // WKWebView默认拦截scheme 需在下面方法手动打开
    if ([navigationAction.request.URL.absoluteString hasPrefix:@"https://itunes"]) { // 对应的scheme
        [[UIApplication sharedApplication] openURL:navigationAction.request.URL];
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation
{
    
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [self endRequests:_webView];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    NSLog(@"加载失败： %@", error);
    
    
    
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    NSLog(@"网页加载失败： %@", error);
    [self startRequests:_webView];
    
    NSURL *url = [NSURL URLWithString:self.urlStr];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:req];
}
@end
