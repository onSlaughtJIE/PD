//
//  YYLoctionDetailDataVC.m
//  caipiao
//
//  Created by 挣钱宝 on 17/4/16.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYMyVC.h"
#import "YYLoctionCell.h"
#import "YYLoctionNummberDetailVC.h"
#import "YYLoctionDetailDataVC.h"
#import "YYFeedbackVC.h"
#import "YYProblemVC.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
@interface YYMyVC ()
{
    NSArray * _investmerntArray;  //title
}
@end

@implementation YYMyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = ViewBackgroundColor;
    self.title =@"我的";
    self.tableView.backgroundColor = ViewBackgroundColor;
    _investmerntArray = @[@"用户",@"摇号记录",@"意见反馈",@"常见问题",@"分享给好友",@"关于我们",@"退出登录",@"退出登录"];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    if ([[userDefault objectForKey:@"name"] isEqualToString:@"1"] || [userDefault objectForKey:@"name"] == nil) {
        return 1;
    }else
    {
        return 4;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section ==0) {
        return 1;
    }else
    {
        return 2;
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
        
        if ([[userDefault objectForKey:@"name"] isEqualToString:@"1"] || [userDefault objectForKey:@"name"] == nil) {
            [self loginView:cell];
        }else
        {
            [self userView:cell];
        }
        return cell;
    }else
    {
        YYLoctionCell  *cell = [[[NSBundle mainBundle] loadNibNamed:@"YYLoctionCell" owner:nil options:nil] lastObject];
        
       cell.titleContent = _investmerntArray[indexPath.row+(indexPath.section-1)*2+1];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
    
}
-(void)userView:(UITableViewCell *)cell
{
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 20, 35, 35)];
    imageView.image = [UIImage imageNamed:@"用户"];
    [cell addSubview:imageView];
    
    UILabel *nameLB = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, screenW-100, 50)];
    nameLB.text = [userDefault objectForKey:@"name"];
    [cell addSubview:nameLB];
}
-(void)loginView:(UITableViewCell *)cell
{
    UIButton *bt = [[UIButton alloc] initWithFrame:CGRectMake(20, 20, screenW/2-40, 40)];
    [bt setBackgroundColor:[UIColor whiteColor]];
    bt.tag = 1;
    [bt addTarget:self action:@selector(btClick:) forControlEvents:UIControlEventTouchUpInside];
    [bt.layer setCornerRadius:5];
    [bt.layer setBorderColor:sxyColor.CGColor];
    [bt.layer setBorderWidth:1];
    [bt setTitle:@"注册" forState:UIControlStateNormal];
    [bt setTitleColor:sxyColor forState:UIControlStateNormal];
    [cell addSubview:bt];
    UIButton *bt2 = [[UIButton alloc] initWithFrame:CGRectMake(20+screenW/2, 20, screenW/2-40, 40)];
    [bt2 setBackgroundColor:sxyColor];
    [bt.layer setCornerRadius:5];
    [bt2 setTitle:@"登录" forState:UIControlStateNormal];
    [bt2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    bt2.tag = 2;
    [bt2 addTarget:self action:@selector(btClick:) forControlEvents:UIControlEventTouchUpInside];
    [cell addSubview:bt2];
}
-(void)btClick:(UIButton *)bt
{
    if (bt.tag == 1) {
        
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        RegisterViewController *loginVC = [sb instantiateViewControllerWithIdentifier:@"RegisterViewController"];
        [self.navigationController pushViewController:loginVC animated:YES];
    }else
    {
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        LoginViewController *loginVC = [sb instantiateViewControllerWithIdentifier:@"LoginViewController"];
        [self.navigationController pushViewController:loginVC animated:YES];
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        
    }else
    {
        
        switch (indexPath.section) {
            case 1:
            {
                if (indexPath.row == 0) {
                    YYLoctionDetailDataVC *loction = [YYLoctionDetailDataVC new];
                    loction.title = @"选号记录";
                    loction.view.backgroundColor = ViewBackgroundColor;
                    [self.navigationController pushViewController:loction animated:YES];
                }else
                {
                    YYFeedbackVC *loction = [YYFeedbackVC new];
                    loction.title = @"意见反馈";
                    loction.view.backgroundColor = ViewBackgroundColor;
                    [self.navigationController pushViewController:loction animated:YES];
                }
            }
                break;
            case 2:
            {
                if (indexPath.row == 0) {
                    YYProblemVC *loction = [YYProblemVC new];
                    loction.title = @"常见问题";
                    loction.view.backgroundColor = ViewBackgroundColor;
                    [self.navigationController pushViewController:loction animated:YES];
                }else
                {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"(彩宝彩票)                           " message:@"亲口推荐给你的好友吧                           谢谢^_^" preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        
                        
                    }];
                    [alert addAction:action1];
                    
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
                break;
            case 3:
            {
                if(indexPath.row == 0)
                {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"(彩宝集团)                           " message:@"北京彩宝集团" preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        
                        
                    }];
                    [alert addAction:action1];
                    
                    [self presentViewController:alert animated:YES completion:nil];
                }else
                {
                    [userDefault setObject:@"1" forKey:@"name"];
                    [self showHint:@"退出登录成功"];
                    [self.tableView reloadData];
                }
                
            }
                break;
            default:
                break;
        }
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        return 70;
    }else
    {
        return 50;
    }
}

@end
