//
//  YYNavigationController.h
//  快乐背单词
//
//  Created by 酷食科技 on 16/11/10.
//  Copyright © 2016年 乐学. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYNavigationController : UINavigationController

@end
