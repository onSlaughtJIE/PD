//
//  YYListVC.m
//  sasa
//
//  Created by 挣钱宝 on 17/4/15.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import "YYListVC.h"
#import "YYListCell.h"
#import "YYListDetailVC.h"
@interface YYListVC ()
@property(nonatomic,strong)NSMutableArray *dataAArr;
@property(nonatomic,strong)NSArray *titleArr;
@property(nonatomic,strong)NSArray *jsonNameArr;
@end

@implementation YYListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSData *JSONData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"shuzicai" ofType:@"json"]];
    
    NSMutableDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingAllowFragments error:nil];
    [self startRequests:self.navigationController.view];
    [requestClass newconsultingRequestImage:nil andOne:nil andTwo:nil andThree:nil andDitc:nil andDistinguish:2 success:^(BOOL state, NSDictionary *resultDict) {
        [self endRequests:self.navigationController.view];
        self.dataAArr = [dataDic objectForKey:@"result"];
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        [self endRequests:self.navigationController.view];
        self.dataAArr = [dataDic objectForKey:@"result"];
        [self.tableView reloadData];
    }];
    
    
    _titleArr = @[@"双色球",@"大乐透",@"福彩3D",@"排列3",@"排列5",@"七星彩"];
    _jsonNameArr = @[@"shuangseqiu",@"dalexiu-1",@"fucai3d-1",@"pailie3-1",@"pailiewu-1",@"qixingcai-1"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return self.dataAArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return 1;
}
-(NSMutableArray *)creadDataArr
{
    NSArray *arr = [NSArray arrayWithObjects:@"双色球",@"第17042期",@"2017-04-15", nil];
    NSArray *arr2 = [NSArray arrayWithObjects:@"1",@"3",@"22",@"25",@"27",@"29",@"35" ,nil];
    NSMutableDictionary *dataDic = [[NSMutableDictionary alloc] initWithCapacity:0];
    [dataDic setObject:arr forKey:@"titleContent"];
    [dataDic setObject:arr2 forKey:@"colorContent"];
    
    NSMutableArray *dataArr = [NSMutableArray arrayWithCapacity:0];;
    [dataArr addObject:dataDic];
    [dataArr addObject:dataDic];
    return dataArr;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableDictionary *dataDic = self.dataAArr[indexPath.section];
    
    
    NSArray *dataArrAll = dataDic[@"payload3"];
    
    
    
    NSArray *dataArrLeft = [dataArrAll[0] objectForKey:@"items"];
    NSArray *dataArrRight = [[NSArray alloc] init];
    if (dataArrAll.count>1) {
        dataArrRight = [dataArrAll[1] objectForKey:@"items"];
    }
    
    
    YYListCell *cell = [[YYListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell" andTypeNummber:dataArrLeft.count+dataArrRight.count andcolorNummber:dataArrLeft.count-1];
    
    
    cell.dataDic = self.dataAArr[indexPath.section];
    cell.title = _titleArr[indexPath.section];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YYListDetailVC *detailVC = [YYListDetailVC new];
    detailVC.title = _titleArr[indexPath.section];
    detailVC.jsonName =_jsonNameArr[indexPath.section];
    
    [self.navigationController pushViewController:detailVC animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

-(NSMutableArray *)dataAArr
{
    if (!_dataAArr) {
        _dataAArr  = [NSMutableArray arrayWithCapacity:0];
    }
    return _dataAArr;
}
-(void)startRequests:(UIView *)view
{
    MBProgressHUD *HUD = [MBProgressHUD showHUDAddedTo:view animated:YES];
    //设置对话框文字
    HUD.labelText = @"加载中...";
    HUD.alpha = 0.5;
    HUD.labelFont = [UIFont systemFontOfSize:15];
    
}
-(void)endRequests:(UIView *)view
{
    [MBProgressHUD hideHUDForView:view animated:YES];
}

@end
