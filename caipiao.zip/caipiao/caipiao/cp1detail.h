//
//  cp1detail.h
//  cp
//
//  Created by 酷食科技 on 17/4/15.
//  Copyright © 2017年 自学. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cp1detail : UITableViewController

@end
