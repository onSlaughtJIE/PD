//
//  YYListWebVC.h
//  caipiao
//
//  Created by apple on 2017/4/18.
//  Copyright © 2017年 公司名. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYListWebVC : UIViewController
@property (copy,nonatomic)NSString *UrlStr;
@property (assign,nonatomic) NSInteger type;
@end
