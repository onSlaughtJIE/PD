//
//  InvestmentMainPage.h
//  
//
//  Created by 挣钱宝 on 15/10/16.
//
//

#import <UIKit/UIKit.h>

@interface InvestmentMainPage : UIViewController<UIScrollViewDelegate>
@end
